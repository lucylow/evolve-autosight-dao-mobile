from pathlib import Path
from PIL import Image

project = Path('/home/ubuntu/evolve-chain-mobile')
source = Path('/home/ubuntu/webdev-static-assets/evolve-insight-icon.png')
image = Image.open(source).convert('RGB')
image.thumbnail((1024, 1024), Image.Resampling.LANCZOS)
for name in ('icon.png', 'splash-icon.png', 'favicon.png', 'android-icon-foreground.png'):
    image.save(project / 'assets' / 'images' / name, format='PNG', optimize=True, compress_level=9)
