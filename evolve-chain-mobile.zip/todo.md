# Project TODO

- [ ] Review the provided project materials and extract confirmed product requirements
- [x] Create branded app icon and update mobile app branding configuration
- [x] Implement the Home / Command Center screen
- [x] Implement Explore and initiative detail flow
- [x] Implement Governance proposal list and detail flow
- [x] Implement Profile / Settings screen with local preferences
- [x] Add tab navigation and icon mappings
- [x] Add deterministic local data models for initiatives and proposals
- [x] Configure the Evolve Chain visual theme tokens
- [x] Run TypeScript, lint, and test checks
- [x] Verify core navigation and button interactions
- [ ] Save the first deliverable checkpoint

- [x] Add an inspection workflow tab with staged analysis and human review states
- [x] Add structured inspection result data and evidence summary UI
- [x] Add an inspection detail route and safe review action
- [x] Re-verify mobile navigation and quality checks after improvements

- [x] Add inspection history filtering for all, needs review, and approved records
- [x] Persist human approval decisions locally for the current session
- [x] Add review-state indicators to inspection history rows
- [x] Re-verify inspection navigation and quality checks

- [x] Add an inspection evidence verification screen
- [x] Add audit timeline and verification-state data for inspection records
- [x] Link inspection detail and history to verification flow
- [x] Re-verify trust-state navigation and quality checks

- [x] Add a public-safe component verification share view
- [x] Add QR-style verification payload and copy/share interaction
- [x] Add verification entry point from trust-layer details
- [x] Re-verify sharing flow and quality checks

- [x] Replace the QR-style marker with a real generated QR code
- [x] Add verification deep-link handling for shared URLs
- [x] Add scan/share interaction states and fallback messaging
- [x] Re-verify QR and deep-link flows with quality checks

- [x] Add an Inspect QR scanning entry point
- [x] Add safe scanned-result parsing and verification lookup states
- [x] Add camera permission and unavailable-device fallback UI
- [x] Re-verify scanning navigation and quality checks

- [x] Persist recent successful and unsuccessful scan attempts locally
- [x] Add recent scan history to the scanner fallback and results flow
- [x] Add lookup status feedback for local and unavailable records
- [x] Re-verify scan history navigation and quality checks

- [x] Make recent scan rows tappable to reopen known verification records
- [x] Add a clear scan history control
- [x] Add offline and sync-status feedback to the scanner fallback
- [x] Re-verify scan history interactions and quality checks

- [x] Add last-synced status and local queue count to scanner fallback
- [x] Add retry-sync interaction with success and failure feedback
- [x] Add confirmation feedback after clearing scan history
- [x] Re-verify offline sync states and quality checks

- [x] Add network connectivity awareness to the scanner sync card
- [x] Add synced or local-only status badges to recent scan rows
- [x] Adjust retry behavior based on online or offline state
- [x] Re-verify network-state interactions and quality checks

- [x] Add automatic sync when connectivity returns
- [x] Display current network type in the scanner sync card
- [x] Add reconnect feedback and sync-complete messaging
- [x] Re-verify automatic sync states and quality checks

- [x] Add synced, pending, and local-only badges to recent scan rows
- [x] Persist per-scan sync state with the scan history
- [x] Update per-scan states after manual and automatic sync
- [x] Re-verify per-scan queue feedback and quality checks

- [x] Add queue filters for all, pending, synced, and local-only scans
- [x] Add individual retry controls for unresolved scan records
- [x] Persist per-record retry outcomes and feedback
- [x] Re-verify queue management interactions and quality checks

- [x] Add per-record retry counters and last-attempt feedback
- [x] Add queue summary totals for pending, synced, and local-only scans
- [x] Add clearer per-record sync error messaging
- [x] Re-verify queue diagnostics and quality checks

- [x] Add a retry history sheet for individual scan records
- [x] Add exportable queue diagnostics using the native share sheet
- [x] Add audit-oriented summary labels and timestamps
- [x] Re-verify audit diagnostics interactions and quality checks

- [x] Add an individual audit detail sheet for each scan record
- [x] Show full retry history context and current sync state per record
- [x] Link audit rows to verification records when available
- [x] Re-verify audit detail interactions and quality checks

- [x] Add persisted retry-event timelines to scan records
- [x] Show event time, outcome, and network context in audit detail
- [x] Add audit trace summary for each scan record
- [x] Re-verify audit timeline interactions and quality checks

- [x] Add event filters for all, queued, failed, and synced audit events
- [x] Add filtered event counts to individual audit detail
- [x] Add failure-focused triage messaging and empty states
- [x] Re-verify audit event filters and quality checks

- [x] Export the currently filtered audit event set
- [x] Add a retry-failed-events action for a selected record
- [x] Add safe retry feedback for offline and successful outcomes
- [x] Re-verify audit actions and quality checks

- [x] Add a retry confirmation sheet with affected-event counts
- [x] Add JSON audit export for filtered record events
- [x] Add CSV audit export for filtered record events
- [x] Re-verify export and retry confirmation interactions

- [x] Add a compact audit summary to the selected record detail
- [x] Add a clear handoff action from audit detail to verification sharing
- [x] Keep audit export payloads bounded to the active filtered events
- [x] Re-verify lightweight audit interactions and quality checks

- [x] Add stable acknowledgement IDs to audit events and JSON/CSV exports
- [x] Add specific failed-event labels and acknowledgement context to retry confirmation
- [x] Add file-based JSON and CSV export using the device sharing flow
- [x] Re-verify external exports and retry feedback quality checks

- [x] Add backend-issued acknowledgement ID support with safe local fallback
- [x] Add selectable audit date range and export filename metadata
- [x] Add import-side JSON or CSV integrity validation and user feedback
- [x] Re-verify backend IDs, date filters, exports, and import validation

- [x] Improve scanner queue resilience for duplicate scans and backend acknowledgement failures
- [x] Improve audit sheet usability with clearer loading, empty, and accessibility feedback
- [x] Add native-safe interaction feedback for important scanner actions
- [x] Re-run TypeScript, lint, tests, and save a new checkpoint

- [x] Add a validated audit import preview before accepting external records
- [x] Improve per-record acknowledgement failure and retry feedback
- [x] Add focused tests for audit preview and retry-state behavior
- [x] Re-run quality checks and save the next checkpoint

- [x] Add a clear pending-acknowledgement summary to the audit queue
- [x] Add safer retry feedback for mixed success and failure outcomes
- [x] Improve audit row accessibility and status explanation text
- [x] Re-run quality checks and save the next checkpoint

- [x] Add persisted retry scheduling metadata and next-attempt visibility
- [x] Improve audit event readability with clearer acknowledgement and failure context
- [x] Add focused tests for retry scheduling metadata
- [x] Re-run quality checks and save the next checkpoint

- [x] Enforce persisted retry windows for automatic and manual retries
- [x] Add a clearly labeled retry-now override with operator confirmation
- [x] Add focused tests for retry-window eligibility
- [x] Re-run quality checks and save the next checkpoint

- [x] Add a live relative countdown for scheduled retries
- [x] Add a queue filter for records that are due to retry
- [x] Add persisted operator override reasons to retry audit events
- [x] Re-run quality checks and save the next checkpoint

- [x] Add a queue-level action to retry all due records with confirmation
- [x] Include retry countdown and override context in audit exports
- [x] Add focused tests for batch retry selection and export metadata
- [x] Re-run quality checks and save the next checkpoint

- [x] Add a batch retry result summary for succeeded, failed, and skipped records
- [x] Add a persisted operator activity log for batch retries and validated imports
- [x] Add focused tests for batch result aggregation and activity entries
- [x] Re-run quality checks and save the next checkpoint

- [x] Add JSON and CSV export for persisted operator activity
- [x] Add activity filtering by operation type and date
- [x] Group backend acknowledgement failures by diagnostic category
- [x] Re-run quality checks and save the next checkpoint

- [x] Add a diagnostics summary view with grouped failure counts and trend context
- [x] Add import validation for externally exchanged operator activity files
- [x] Add audit export manifest linking activity entries and acknowledgement IDs
- [x] Re-run quality checks and save the next checkpoint

- [x] Inspect current TypeScript, lint, runtime-log, and failure-path errors
- [x] Add defensive error handling for sync, acknowledgements, imports, and exports
- [x] Add user-facing recovery states and safe fallbacks without losing local audit data
- [x] Add regression tests, re-run quality checks, and save the next checkpoint

- [x] Audit remaining runtime warnings and async failure paths
- [x] Add retryable recovery controls for failed imports, exports, and sync operations
- [x] Replace or isolate deprecated runtime prop usage where it is owned by project code
- [x] Add regression coverage, re-run quality checks, and save the next checkpoint

- [x] Review current camera scanning and inspection result paths
- [x] Improve scan-quality feedback, camera state recovery, and inspection guidance
- [x] Add deterministic tests for scan parsing and quality-state decisions
- [x] Re-run quality checks and save the next checkpoint

- [x] Add camera zoom control with safe bounds and reset behavior
- [x] Add a capture-quality readiness state before accepting scanned payloads
- [x] Add deterministic tests for zoom bounds and readiness guidance
- [x] Re-run quality checks and save the next checkpoint

- [x] Add deterministic scan confidence and framing-state evaluation
- [x] Add visible framing feedback around the scan target
- [x] Add native-safe camera recovery when the preview becomes unavailable
- [x] Add tests, re-run quality checks, and save the next checkpoint

- [x] Add a camera retry action that remounts a failed preview
- [x] Add clearer scan-state feedback and native haptic transitions
- [x] Improve scan-again reset behavior for zoom, torch, and confidence state
- [x] Add tests, re-run quality checks, and save the next checkpoint

- [x] Add pinch-to-zoom support or a native-safe gesture fallback
- [x] Add scan-session quality summary with confidence and framing adjustments
- [x] Improve inspection capture readiness and recovery feedback
- [x] Add tests, re-run quality checks, and save the next checkpoint

- [x] Add deterministic image-capture quality heuristics for inspection readiness
- [x] Add visible inspection capture guidance and recovery feedback
- [x] Preserve safe fallback behavior when image metadata is unavailable
- [x] Add tests, re-run quality checks, and save the next checkpoint

- [x] Add native inspection photo capture with permission and unavailable-camera recovery
- [x] Add review-before-analysis state with safe recapture behavior
- [x] Add deterministic photo-readiness metadata heuristics and tests
- [x] Re-run quality checks and save the next checkpoint

- [x] Add a capture framing overlay and operator guidance during inspection photos
- [x] Add local image-quality feedback using safe photo metadata heuristics
- [x] Persist reviewed photo metadata into inspection audit context
- [x] Add tests, re-run quality checks, and save the next checkpoint

- [x] Add richer local capture diagnostics for resolution, aspect ratio, EXIF, and file-size evidence
- [x] Surface reviewed photo metadata in inspection detail and verification audit context
- [x] Add deterministic tests for diagnostic summaries and audit metadata formatting
- [x] Re-run quality checks and save the next checkpoint

- [x] Add lightweight pixel-level blur and exposure estimation to photo quality scoring
- [x] Add component-specific framing templates for housings, labels, and flat surfaces
- [x] Add side-by-side current versus previous capture comparison with safe persistence
- [x] Add deterministic tests, run quality checks, and save the next checkpoint

- [x] Audit recent computer-vision, camera, image-decoding, and local-storage error paths
- [x] Add defensive recovery states and safe fallbacks for capture and pixel analysis
- [x] Add regression tests for error normalization and recovery behavior
- [x] Re-run quality checks and save the next checkpoint

- [x] Add transparent pixel-quality diagnostic explanations and confidence bands
- [x] Improve capture guidance with live template-specific readiness cues
- [x] Add safe handling for stale or inaccessible comparison images
- [x] Add regression tests, run quality checks, and save the next checkpoint

- [x] Add component-aware region-of-interest sampling for pixel quality scoring
- [x] Persist pixel confidence and explanations into reviewed inspection metadata
- [x] Surface component-aware scoring context in inspection and verification audit views
- [x] Add regression tests, run quality checks, and save the next checkpoint

- [x] Add deterministic perspective and edge-alignment checks for component captures
- [x] Add component-specific live guidance for tilt, orientation, and edge visibility
- [x] Persist perspective and alignment diagnostics into capture metadata and audit context
- [x] Add regression tests, run quality checks, and save the next checkpoint

- [x] Add deterministic geometric edge and perspective evidence to capture diagnostics
- [x] Add stronger live capture guidance for alignment and component boundaries
- [x] Persist geometric evidence summaries into inspection audit metadata
- [x] Add regression tests, run quality checks, and save the next checkpoint

- [x] Add an aggregated evidence-confidence score across pixel, geometry, alignment, and metadata signals
- [x] Add stronger component-specific guidance when evidence signals disagree
- [x] Persist aggregated confidence and operator guidance into inspection audit metadata
- [x] Add regression tests, run quality checks, and save the next checkpoint

- [x] Add repeated-capture confidence history and trend context
- [x] Add transparent component calibration thresholds and signal breakdown
- [x] Add low-confidence review and operator override handling without weakening audit traceability
- [x] Add regression tests, run quality checks, and save the next checkpoint

- [x] Add a per-component calibration breakdown for metadata, pixel, alignment, and geometry signals
- [x] Add an auditable low-confidence review decision with operator reason capture
- [x] Surface calibration and review context in inspection audit diagnostics
- [x] Add regression tests, run quality checks, and save the next checkpoint

- [x] Add visual calibration bars for component signal contributions
- [x] Require a non-empty operator reason before approving low-confidence evidence
- [x] Persist threshold-version context with the reviewed capture metadata
- [x] Add regression tests, run quality checks, and save the next checkpoint

- [x] Add structured low-confidence review reason categories
- [x] Add a triage view for low-confidence and conflicting evidence captures
- [x] Persist selected review category and calibration context in audit metadata
- [x] Add regression tests, run quality checks, and save the next checkpoint

- [x] Add a triage filter for low-confidence and conflicting evidence captures
- [x] Add reason-specific remediation guidance for common capture failures
- [x] Add aggregate capture-quality counts and trend context to the inspection workflow
- [x] Add regression tests, run quality checks, and save the next checkpoint

- [x] Add trend-aware quality summaries by component and capture template
- [x] Add faster operator review actions for repeated or predictable capture issues
- [x] Persist trend interpretation and component quality context in audit metadata
- [x] Add regression tests, run quality checks, and save the next checkpoint

- [x] Add historical quality visibility for repeated captures and component templates
- [x] Add targeted recapture actions tied to the selected failure category
- [x] Add exportable inspection-quality summary data without exposing private images
- [x] Add regression tests, run quality checks, and save the next checkpoint

- [x] Add historical capture trend interpretation across recent evidence reviews
- [x] Add issue-specific recapture shortcut actions for focus, exposure, alignment, and metadata gaps
- [x] Add a privacy-safe report summary with explicit excluded-image-data messaging
- [x] Add regression tests, run quality checks, and save the next checkpoint

- [x] Add historical quality review context per component and template
- [x] Add component-specific remediation summaries for recurring issues
- [x] Add privacy-safe operator reporting context to the inspection review surface
- [x] Add regression tests, run quality checks, and save the next checkpoint

- [x] Add one-tap remediation actions for structured review reasons
- [x] Add compact historical quality visibility for recent component captures
- [x] Add privacy-safe evidence-report status messaging for operators
- [x] Add regression tests, run lightweight quality checks, and save the next checkpoint

- [x] Add actionable remediation preset controls to the capture review card
- [x] Add stronger historical quality review context for the selected component
- [x] Preserve explicit privacy-safe report messaging during review actions
- [x] Add regression tests, run quality checks, and save the next checkpoint

- [x] Add camera-aware remediation presets for torch, zoom, and framing state
- [x] Add compact historical confidence review for the selected component
- [x] Preserve privacy-safe evidence-report messaging across camera actions
- [x] Add regression tests, run quality checks, and save the next checkpoint

- [x] Make camera remediation presets operational for torch and zoom state
- [x] Add stronger component-level confidence trend context during recapture
- [x] Preserve privacy-safe report messaging across preset-driven camera actions
- [x] Add regression tests, run quality checks, and save the next checkpoint

- [x] Add safe camera-state recovery when native torch or zoom settings cannot be applied
- [x] Add stronger component-level quality history context during recapture
- [x] Preserve privacy-safe evidence-report messaging across camera-state recovery
- [x] Add regression tests, run quality checks, and save the next checkpoint

- [x] Add camera preview readiness and recovery status for native torch and zoom presets
- [x] Add stronger component-specific confidence trend summaries during review
- [x] Preserve privacy-safe audit reporting through camera recovery states
- [x] Add regression tests, run quality checks, and save the next checkpoint

- [x] Add enterprise plan visibility and value-focused monetization entry point
- [x] Add deterministic feature entitlements that preserve core inspection access
- [x] Add privacy-conscious upgrade prompts and clear locked-feature explanations
- [x] Add monetization tests, run quality checks, and save the next checkpoint

- [x] Add a dedicated plan comparison screen with feature-by-feature entitlement clarity
- [x] Add a privacy-conscious organization upgrade request flow with confirmation state
- [x] Add entitlement-aware locked states for audit exports and advanced triage entry points
- [x] Add regression tests, run quality checks, and save the next checkpoint

- [x] Persist the selected workspace plan and restore it safely on launch
- [x] Record privacy-safe upgrade-request history and visible request status
- [x] Strengthen gated capability states with actionable enterprise value messaging
- [x] Add regression tests, run quality checks, and save the next checkpoint

- [x] Add an administrator-facing workspace plan control with explicit local-only status
- [x] Persist privacy-safe plan-change events with actor and reason metadata
- [x] Strengthen entitlement boundaries so local plan state never implies server authorization
- [x] Add regression tests, run quality checks, and save the next checkpoint

- [x] Add an organization-facing plan-change audit history view
- [x] Add clear local-preview and server-authorization state explanations
- [x] Strengthen enterprise upgrade messaging without exposing private evidence
- [x] Add regression tests, run quality checks, and save the next checkpoint

- [x] Add plan-history filters and privacy-safe export on Profile
- [x] Add a clear active subscription tier badge and status explanation
- [x] Add a contextual upgrade prompt within plan-change history
- [x] Add regression tests, run quality checks, and save the next checkpoint

- [x] Add plan-history filters and privacy-safe export on Profile
- [x] Add a clear active subscription tier badge and status explanation
- [x] Add a contextual upgrade prompt within plan-change history
- [x] Add regression tests, run quality checks, and save the next checkpoint

- [x] Refine shared interface spacing, hierarchy, and control styling
- [x] Improve Profile monetization card readability and active states
- [x] Add clearer accessibility and interaction feedback across updated UI
- [x] Run quality checks, verify the visual result, and save the next checkpoint

- [x] Refine tab navigation hierarchy and active-state presentation
- [x] Improve inspection and governance card hierarchy and state readability
- [x] Add clearer interaction feedback and accessibility labels to updated workflow controls
- [x] Run quality checks, verify the visual result, and save the next checkpoint

- [x] Refine Explore filters, initiative cards, and navigation affordances
- [x] Improve Inspect workflow card hierarchy and review-state readability
- [x] Add clearer accessibility labels and interaction feedback to Explore and Inspect controls
- [x] Run quality checks, verify the visual result, and save the next checkpoint

- [x] Refine inspection history filters and status rows
- [x] Improve inspection detail hierarchy and audit context readability
- [x] Add clearer recovery-state presentation and accessibility feedback
- [x] Run quality checks, verify the visual result, and save the next checkpoint

- [x] Refine verification detail trust-state hierarchy and evidence presentation
- [x] Improve scan-history rows, recovery feedback, and action affordances
- [x] Add clearer accessibility labels and interaction feedback to verification controls
- [x] Run quality checks, verify the visual result, and save the next checkpoint

- [x] Refine public verification trust-state presentation and hierarchy
- [x] Improve share actions and privacy-safe explanatory messaging
- [x] Add clearer accessibility labels and recovery feedback to sharing controls
- [x] Run quality checks, verify the visual result, and save the next checkpoint

- [x] Add a copy-link fallback beside native verification sharing
- [x] Add a clear public-versus-private data legend
- [x] Improve share success, failure, and accessibility feedback
- [x] Run quality checks, verify the visual result, and save the next checkpoint

- [x] Refine share-screen action hierarchy and status feedback
- [x] Improve copy/share confirmation and recovery presentation
- [x] Extend consistent interaction polish to adjacent verification controls
- [x] Run quality checks, verify the visual result, and save the next checkpoint

- [x] Refine verification back-navigation and share action hierarchy
- [x] Improve narrow-screen share layout and action wrapping
- [x] Add consistent touch feedback and accessibility states to updated controls
- [x] Run quality checks, verify the visual result, and save the next checkpoint

- [x] Improve tab-bar icon and label legibility in compact previews
- [x] Refine active-tab contrast, spacing, and safe-area presentation
- [x] Improve responsive spacing on primary Home and tab surfaces
- [x] Run quality checks, verify the visual result, and save the next checkpoint

- [x] Clarify primary inspection and verification next actions
- [x] Improve workflow progression and completion feedback
- [x] Strengthen loading, empty, and recovery states across primary flows
- [x] Run quality checks, verify the user experience, and save the next checkpoint

- [x] Clarify capture-to-analysis processing transitions and completion feedback
- [x] Add actionable camera preview recovery controls
- [x] Add actionable persistence-failure recovery guidance without losing local evidence
- [x] Run quality checks, verify the user experience, and save the next checkpoint

- [x] Add compact capture and analysis progress visibility
- [x] Add explicit local-save and offline evidence status
- [x] Preserve safe local evidence while improving recovery guidance
- [x] Run quality checks, verify the user experience, and save the next checkpoint

- [x] Add a concise post-analysis completion summary
- [x] Show saved-at context for retained inspection evidence
- [x] Improve accessibility and recovery guidance around completed analysis
- [x] Run quality checks, verify the user experience, and save the next checkpoint
