# Evolve Chain / AutoSight DAO — Mobile Interface Design

## Product Direction

The first release is a mobile command center for the Evolve Chain and AutoSight DAO ecosystem. It should help a member understand the DAO at a glance, inspect active initiatives, follow governance activity, and discover the next useful action without requiring a desktop dashboard. The visual language is dark, technical, and calm: a deep space background, electric cyan for interaction, violet for protocol intelligence, and restrained green for healthy network signals.

The initial implementation will use local, deterministic content to establish the experience and navigation. Live wallet connectivity, governance transactions, and chain data should be added only after their data contracts and security requirements are confirmed.

## Screen List

### 1. Home / Command Center

The home tab opens with a compact brand header, a network status pill, and a single sentence describing the current state of the ecosystem. The primary content is a hero card with an “AutoSight signal” summary, followed by three quick metrics: active proposals, open bounties, and contributor momentum. A “Continue exploring” row links to the most relevant active initiative. The screen uses a `FlatList` or scrollable section list and keeps the primary actions within thumb reach.

### 2. Explore

The Explore tab presents initiatives, proposals, and community missions as filterable cards. The first iteration includes segmented filters for “All,” “Governance,” and “Missions,” along with a compact search affordance. Each card shows a category label, title, short description, status, and a small participation cue. Tapping a card opens its detail screen.

### 3. Initiative Detail

The detail screen contains a back affordance, status and category labels, title, overview, impact indicators, timeline, and a clear primary action. The primary action is intentionally safe in the first release: “View mission” or “Review proposal” opens an informational view rather than signing a transaction. A bottom action area stays accessible above the home indicator.

### 4. Governance

The Governance tab is a focused list of DAO proposals with status chips such as “Voting,” “Queued,” and “Executed.” A featured proposal card explains the decision in plain language, with vote direction indicators and a link to read the full rationale. The first release does not submit votes; it provides a clear review flow and labels transaction actions as a future integration point.

### 5. Profile / Settings

The profile tab provides an identity placeholder for the member, contribution summary, notification preferences, appearance selection, and a short “About AutoSight” section. No account or wallet authentication is introduced unless explicitly requested. Local preferences are appropriate for this first build.

## Key User Flows

1. **Understand the current ecosystem state:** User opens Home → reads AutoSight signal → scans network metrics → taps the recommended initiative → reviews its detail.
2. **Discover an initiative:** User taps Explore → selects a category filter → taps an initiative card → reads the overview and impact → taps the informational primary action.
3. **Review governance:** User taps Governance → selects an active proposal → reads the proposal summary and timeline → returns to the proposal list.
4. **Adjust local preferences:** User taps Profile → changes appearance or notification preference → sees immediate visual confirmation.

## Visual System

| Element | Direction |
|---|---|
| Background | `#070A12` midnight navy, with `#0E1424` elevated surfaces |
| Primary accent | `#6EE7F9` electric cyan for actions and active states |
| Secondary accent | `#9B8AFB` protocol violet for insight cards and governance highlights |
| Positive state | `#62E6A7` mint green for healthy or executed states |
| Attention state | `#F6C96B` warm amber for voting or pending states |
| Primary text | `#F5F7FF` soft white |
| Secondary text | `#98A2B8` cool slate |
| Borders | `#202A40` low-contrast blue slate |
| Typography | SF Pro / system sans; strong 30–34pt display title, 17pt section titles, 13–15pt supporting text |
| Shape language | 18–24pt rounded cards, 12pt chips, thin dividers, generous vertical spacing |

## Interaction Standards

The app follows iOS Human Interface Guidelines for portrait orientation and one-handed use. All screens use `ScreenContainer` for safe-area handling. Primary actions use visible press feedback and restrained haptics where supported. Destructive or irreversible blockchain actions are not exposed in the initial local prototype. Empty, loading, and unavailable-data states must be explicit rather than filled with invented live metrics.
