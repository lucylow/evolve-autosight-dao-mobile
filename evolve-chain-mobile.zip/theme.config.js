/** @type {const} */
const themeColors = {
  primary: { light: '#2E6BFF', dark: '#6EE7F9' },
  background: { light: '#F6F8FC', dark: '#070A12' },
  surface: { light: '#FFFFFF', dark: '#0E1424' },
  foreground: { light: '#101828', dark: '#F5F7FF' },
  muted: { light: '#667085', dark: '#98A2B8' },
  border: { light: '#E4E9F2', dark: '#202A40' },
  success: { light: '#158F62', dark: '#62E6A7' },
  warning: { light: '#B7791F', dark: '#F6C96B' },
  error: { light: '#C53B53', dark: '#FF7C93' },
};

module.exports = { themeColors };
