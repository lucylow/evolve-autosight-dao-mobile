import { safeReadJson, safeWriteJson } from "./safe-storage";
import type { MonetizationPlan } from "./monetization";

export const WORKSPACE_PLAN_KEY = "evolve-insight.workspace-plan.v1";
export const UPGRADE_REQUESTS_KEY = "evolve-insight.upgrade-requests.v1";
export const PLAN_CHANGE_EVENTS_KEY = "evolve-insight.plan-change-events.v1";

export type UpgradeRequestStatus = "prepared" | "sent";
export type PlanChangeEvent = {
  id: string;
  from: MonetizationPlan;
  to: MonetizationPlan;
  actor: "workspace-admin";
  reason: string;
  createdAt: string;
  authorizationSource: "local-preview-only";
};

export type UpgradeRequest = {
  id: string;
  requestedPlan: Exclude<MonetizationPlan, "community">;
  organizationLabel?: string;
  status: UpgradeRequestStatus;
  createdAt: string;
  includesPrivateEvidence: false;
};

export async function loadWorkspacePlan(): Promise<{ plan: MonetizationPlan; recovered: boolean }> {
  const result = await safeReadJson<{ plan?: MonetizationPlan }>(WORKSPACE_PLAN_KEY);
  const plan = result.value?.plan;
  if (plan === "community" || plan === "operations" || plan === "network") return { plan, recovered: false };
  return { plan: "community", recovered: Boolean(result.error || result.value) };
}

export async function persistWorkspacePlan(plan: MonetizationPlan) {
  return safeWriteJson(WORKSPACE_PLAN_KEY, { plan, updatedAt: new Date().toISOString(), authorizationSource: "local-preview-only" });
}

export async function loadPlanChangeEvents(): Promise<{ events: PlanChangeEvent[]; recovered: boolean }> {
  const result = await safeReadJson<PlanChangeEvent[]>(PLAN_CHANGE_EVENTS_KEY);
  if (Array.isArray(result.value)) {
    const events = result.value.filter((event) => event && event.actor === "workspace-admin" && event.authorizationSource === "local-preview-only" && typeof event.reason === "string");
    return { events, recovered: events.length !== result.value.length };
  }
  return { events: [], recovered: Boolean(result.error || result.value) };
}

export function formatPlanChangeHistory(events: PlanChangeEvent[]) {
  const header = "Evolve Insight plan-change history\nAuthorization source: local preview only\n";
  const rows = events.map((event) => `${event.createdAt},${event.from},${event.to},${event.actor},${event.authorizationSource},${event.reason.replace(/[\\n,]/g, " ")}`);
  return `${header}createdAt,from,to,actor,authorizationSource,reason\n${rows.join("\\n")}`;
}

export async function recordPlanChange(input: { from: MonetizationPlan; to: MonetizationPlan; reason: string }) {
  const stored = await loadPlanChangeEvents();
  const history = stored.events;
  const event: PlanChangeEvent = {
    id: `plan-change-${Date.now()}`,
    from: input.from,
    to: input.to,
    actor: "workspace-admin",
    reason: input.reason.trim(),
    createdAt: new Date().toISOString(),
    authorizationSource: "local-preview-only",
  };
  const result = await safeWriteJson(PLAN_CHANGE_EVENTS_KEY, [event, ...history].slice(0, 20));
  return { event, ok: result.ok, error: result.error };
}

export async function loadUpgradeRequests(): Promise<{ requests: UpgradeRequest[]; recovered: boolean }> {
  const result = await safeReadJson<UpgradeRequest[]>(UPGRADE_REQUESTS_KEY);
  if (Array.isArray(result.value)) {
    const requests = result.value.filter((request) => request && request.includesPrivateEvidence === false && (request.requestedPlan === "operations" || request.requestedPlan === "network"));
    return { requests, recovered: requests.length !== result.value.length };
  }
  return { requests: [], recovered: Boolean(result.error || result.value) };
}

export async function recordUpgradeRequest(input: { requestedPlan: Exclude<MonetizationPlan, "community">; organizationLabel?: string; status?: UpgradeRequestStatus }) {
  const existing = await loadUpgradeRequests();
  const request: UpgradeRequest = {
    id: `upgrade-${Date.now()}`,
    requestedPlan: input.requestedPlan,
    organizationLabel: input.organizationLabel?.trim() || undefined,
    status: input.status ?? "prepared",
    createdAt: new Date().toISOString(),
    includesPrivateEvidence: false,
  };
  const result = await safeWriteJson(UPGRADE_REQUESTS_KEY, [request, ...existing.requests].slice(0, 10));
  return { request, ok: result.ok, error: result.error };
}
