import type { OperatorActivity } from "./evolve-data";

export type ActivityFilter = "all" | OperatorActivity["kind"];
export type ActivityDateRange = "all" | "today" | "7d" | "30d";

export function filterOperatorActivity(entries: OperatorActivity[], filter: ActivityFilter, range: ActivityDateRange, now = Date.now()) {
  const days = range === "today" ? 1 : range === "7d" ? 7 : range === "30d" ? 30 : Infinity;
  return entries.filter((entry) => {
    if (filter !== "all" && entry.kind !== filter) return false;
    if (!Number.isFinite(days)) return true;
    const timestamp = Date.parse(entry.time);
    return Number.isNaN(timestamp) || now - timestamp <= days * 24 * 60 * 60 * 1000;
  });
}

export function serializeOperatorActivity(entries: OperatorActivity[], format: "json" | "csv") {
  if (format === "json") return JSON.stringify({ schemaVersion: 1, exportedAt: new Date().toISOString(), records: entries }, null, 2);
  return [
    "# Evolve Insight Operator Activity Export",
    "# schemaVersion=1",
    "id,time,kind,summary,detail",
    ...entries.map((entry) => [entry.id, entry.time, entry.kind, entry.summary, entry.detail].map((value) => `"${value.replaceAll('"', '""')}"`).join(",")),
  ].join("\n");
}

export type ActivityValidationResult = { valid: boolean; recordCount: number; message: string; entries?: OperatorActivity[] };

export function validateOperatorActivityText(text: string, format: "json" | "csv"): ActivityValidationResult {
  try {
    if (format === "json") {
      const value = JSON.parse(text) as { schemaVersion?: number; records?: OperatorActivity[] };
      if (value.schemaVersion !== 1 || !Array.isArray(value.records)) return { valid: false, recordCount: 0, message: "Operator activity metadata is incomplete." };
      const valid = value.records.every((entry) => typeof entry.id === "string" && typeof entry.time === "string" && (entry.kind === "batch-retry" || entry.kind === "audit-import") && typeof entry.summary === "string" && typeof entry.detail === "string");
      return valid ? { valid: true, recordCount: value.records.length, message: `Validated ${value.records.length} operator activity record${value.records.length === 1 ? "" : "s"}.`, entries: value.records } : { valid: false, recordCount: value.records.length, message: "One or more operator activity records failed integrity validation." };
    }
    const lines = text.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
    const header = "id,time,kind,summary,detail";
    const headerIndex = lines.indexOf(header);
    if (headerIndex < 0 || !lines.some((line) => line === "# schemaVersion=1")) return { valid: false, recordCount: 0, message: "Operator activity CSV metadata or header is invalid." };
    const entries = lines.slice(headerIndex + 1).map((line) => line.split(",").map((value) => value.replace(/^\"|\"$/g, ""))).map(([id, time, kind, summary, detail]) => ({ id, time, kind: kind as OperatorActivity["kind"], summary, detail }));
    const valid = entries.every((entry) => Boolean(entry.id && entry.time && (entry.kind === "batch-retry" || entry.kind === "audit-import") && typeof entry.summary === "string" && typeof entry.detail === "string"));
    return valid ? { valid: true, recordCount: entries.length, message: `Validated ${entries.length} operator activity record${entries.length === 1 ? "" : "s"}.`, entries } : { valid: false, recordCount: entries.length, message: "One or more operator activity CSV rows failed integrity validation." };
  } catch {
    return { valid: false, recordCount: 0, message: "The operator activity file is not parseable." };
  }
}

export function getFailureCategory(errorMessage?: string) {
  if (!errorMessage) return "None";
  if (errorMessage.includes("Backend acknowledgement")) return "Backend acknowledgement";
  if (errorMessage.includes("No connection") || errorMessage.includes("offline")) return "Offline connectivity";
  return "Other";
}
