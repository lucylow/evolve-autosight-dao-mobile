export function getNextAttemptAt(now: Date, retryCount: number) {
  const delayMs = Math.min(15 * 60 * 1000, 30 * 1000 * (2 ** Math.max(0, retryCount - 1)));
  return new Date(now.getTime() + delayMs).toISOString();
}

export function formatNextAttempt(value?: string) {
  if (!value) return "";
  return new Date(value).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

export function isRetryDue(value?: string, now = Date.now()) {
  return !value || new Date(value).getTime() <= now;
}

export function formatRetryCountdown(value?: string, now = Date.now()) {
  if (!value) return "";
  const remainingMs = new Date(value).getTime() - now;
  if (remainingMs <= 0) return "Retry due now";
  const totalSeconds = Math.ceil(remainingMs / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return minutes > 0 ? `Retry in ${minutes}m ${seconds}s` : `Retry in ${seconds}s`;
}
