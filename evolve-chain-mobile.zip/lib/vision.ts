export type ScanQuality = "empty" | "malformed" | "verification";
export type CaptureReadiness = "ready" | "needs-light" | "needs-centering";
export type FramingState = "clear" | "adjust";
export type InspectionFrameTemplate = "housing" | "label" | "flat-surface";

export const INSPECTION_FRAME_TEMPLATES: Record<InspectionFrameTemplate, { label: string; detail: string; aspectRatio: number; guide: string }> = {
  housing: { label: "Housing", detail: "Show the full housing and its outer edges.", aspectRatio: 1.25, guide: "Leave a small margin around the housing corners." },
  label: { label: "Label", detail: "Fill the guide with the label and keep text horizontal.", aspectRatio: 1.75, guide: "Avoid glare and keep all printed characters inside the guide." },
  "flat-surface": { label: "Flat surface", detail: "Keep the inspected plane parallel to the camera.", aspectRatio: 1.33, guide: "Use even lighting and avoid shadows crossing the inspection area." },
};
export type PhotoQualityState = "ready" | "review" | "improve";
export type ComponentAlignmentState = "aligned" | "review" | "adjust" | "unavailable";

export type ComponentAlignmentResult = {
  state: ComponentAlignmentState;
  score: number | null;
  label: string;
  message: string;
};

export type EvidenceConfidenceState = "high" | "medium" | "low" | "unavailable";
export type EvidenceConfidenceResult = {
  state: EvidenceConfidenceState;
  score: number | null;
  label: string;
  guidance: string;
};

export const INSPECTION_REVIEW_REASONS = ["blur", "exposure", "alignment", "occlusion", "signal-conflict", "metadata-gap"] as const;
export type InspectionReviewReason = (typeof INSPECTION_REVIEW_REASONS)[number];

export function getInspectionReviewRemediation(reason: InspectionReviewReason): string {
  return { blur: "Hold the device steady, increase light, and recapture with the component filling the guide.", exposure: "Move away from glare or shadows, enable the torch if needed, and recapture.", alignment: "Center the component, keep the camera parallel, and make all visible edges fit inside the guide.", occlusion: "Remove hands, tools, or packaging from the frame before recapturing.", "signal-conflict": "Compare the current image with the previous evidence and recapture if the signals remain inconsistent.", "metadata-gap": "Retake the photo from the native camera so dimensions and capture metadata are available." }[reason];
}

export function getHistoricalQualityInterpretation(scores: number[]): { label: string; guidance: string } {
  if (scores.length < 2) return { label: "Single evidence point", guidance: "Capture another review to establish a reliable quality trend." };
  const delta = scores[scores.length - 1] - scores[0];
  if (delta >= 8) return { label: "Quality improving", guidance: "Recent evidence is stronger than the earliest capture in this review window." };
  if (delta <= -8) return { label: "Quality declining", guidance: "Recent evidence is weaker; prioritize the current remediation guidance before approval." };
  return { label: "Quality stable", guidance: "Recent evidence remains within a stable quality band." };
}

export function formatInspectionQualityReportSummary(input: { total: number; high: number; review: number; unavailable: number; excludedImageData: true }): string {
  return `Inspection quality report · ${input.total} captures · ${input.high} high confidence · ${input.review} review · ${input.unavailable} unavailable. Private image pixels and local image URIs are excluded.`;
}

export function getCameraRemediationPreset(reason: InspectionReviewReason): { torch: "on" | "off" | "auto"; zoom: "reset" | "low"; framing: "center" | "parallel" | "full-edges" } {
  if (reason === "exposure") return { torch: "on", zoom: "reset", framing: "center" };
  if (reason === "alignment") return { torch: "auto", zoom: "reset", framing: "parallel" };
  if (reason === "occlusion") return { torch: "auto", zoom: "low", framing: "full-edges" };
  return { torch: "auto", zoom: "reset", framing: "center" };
}

export function getRemediationShortcut(reason: InspectionReviewReason): { label: string; preset: string } {
  if (reason === "blur") return { label: "Improve focus", preset: "steady-and-brighter" };
  if (reason === "exposure") return { label: "Improve lighting", preset: "reduce-glare" };
  if (reason === "alignment") return { label: "Recenter component", preset: "parallel-and-centered" };
  if (reason === "occlusion") return { label: "Clear component edges", preset: "remove-obstructions" };
  if (reason === "metadata-gap") return { label: "Use native capture", preset: "native-camera" };
  return { label: "Compare evidence", preset: "compare-previous" };
}

export function getComponentRemediationSummary(template: InspectionFrameTemplate, reason: InspectionReviewReason): string {
  const component = INSPECTION_FRAME_TEMPLATES[template].label;
  const base = getInspectionReviewRemediation(reason);
  if (template === "label" && reason === "alignment") return `${component}: keep text horizontal and all characters inside the guide. ${base}`;
  if (template === "flat-surface" && reason === "alignment") return `${component}: keep the plane parallel and avoid perspective skew. ${base}`;
  if (template === "housing" && reason === "occlusion") return `${component}: expose the full outer housing and corner boundaries. ${base}`;
  return `${component}: ${base}`;
}

export function formatComponentHistoryContext(template: InspectionFrameTemplate, scores: number[]): string {
  const interpretation = getHistoricalQualityInterpretation(scores);
  return `${INSPECTION_FRAME_TEMPLATES[template].label} history · ${scores.length} captures · ${interpretation.label}. ${interpretation.guidance}`;
}

export function getTargetedRecaptureAction(input: { pixelState?: "good" | "review" | "poor" | "unavailable"; alignmentState?: "aligned" | "adjust" | "review" | "unavailable"; confidenceState?: EvidenceConfidenceState }): { label: string; guidance: string } {
  if (input.pixelState === "poor") return { label: "Recapture for focus", guidance: "Hold steady and increase light so the component edges remain crisp." };
  if (input.alignmentState === "review" || input.alignmentState === "adjust") return { label: "Recapture for alignment", guidance: "Move parallel to the component and keep every visible edge inside the frame." };
  if (input.confidenceState === "unavailable") return { label: "Recapture with native camera", guidance: "Capture again so dimensions and metadata can be verified." };
  return { label: "Recapture evidence", guidance: "Use the selected template and compare the new image with the previous evidence." };
}

export function formatInspectionQualityExport(records: Array<{ id: string; template: InspectionFrameTemplate; confidence: number; triage?: string }>): string {
  const header = "inspectionId,template,confidence,triage";
  const rows = records.map((record) => [record.id, record.template, record.confidence, record.triage ?? ""].map((value) => `"${String(value).replaceAll('"', '""')}"`).join(","));
  return [header, ...rows].join("\n");
}

export function summarizeComponentQuality(records: Array<{ template: InspectionFrameTemplate; confidence: number }>): Array<{ template: InspectionFrameTemplate; average: number; count: number; trend: "strong" | "review" }> {
  return (["housing", "label", "flat-surface"] as InspectionFrameTemplate[]).map((template) => {
    const matches = records.filter((record) => record.template === template);
    const average = matches.length ? Math.round(matches.reduce((sum, record) => sum + record.confidence, 0) / matches.length) : 0;
    return { template, average, count: matches.length, trend: average >= 85 ? "strong" : "review" };
  });
}

export function summarizeCaptureQuality(states: Array<EvidenceConfidenceState | null | undefined>): { high: number; review: number; unavailable: number; total: number } {
  return states.reduce((summary, state) => {
    summary.total += 1;
    if (state === "high") summary.high += 1;
    else if (state === "unavailable") summary.unavailable += 1;
    else summary.review += 1;
    return summary;
  }, { high: 0, review: 0, unavailable: 0, total: 0 });
}

export function getInspectionReviewReasonLabel(reason: InspectionReviewReason): string {
  return { blur: "Blur or focus", exposure: "Lighting or exposure", alignment: "Alignment or perspective", occlusion: "Component partially occluded", "signal-conflict": "Signals conflict", "metadata-gap": "Missing capture metadata" }[reason];
}

export function getConfidenceTriageLabel(state: EvidenceConfidenceState, trendDelta: number | null): string {
  if (state === "low") return "Priority recapture";
  if (state === "medium" && trendDelta !== null && trendDelta < 0) return "Review declining evidence";
  if (state === "medium") return "Review before approval";
  if (state === "unavailable") return "Metadata review required";
  return "Ready for confirmation";
}

export type CalibrationSignal = { key: "metadata" | "pixel" | "alignment" | "geometry"; label: string; score: number | null; weight: number; contribution: number | null };

export function getCalibrationBreakdown(template: InspectionFrameTemplate, input: { metadataScore: number | null; pixelScore: number | null; alignmentScore: number | null; edgeScore: number | null }): CalibrationSignal[] {
  const weights = template === "label" ? { metadata: 0.2, pixel: 0.3, alignment: 0.3, geometry: 0.2 } : template === "flat-surface" ? { metadata: 0.2, pixel: 0.25, alignment: 0.35, geometry: 0.2 } : { metadata: 0.25, pixel: 0.25, alignment: 0.25, geometry: 0.25 };
  return [
    { key: "metadata", label: "Metadata", score: input.metadataScore, weight: weights.metadata, contribution: input.metadataScore === null ? null : Math.round(input.metadataScore * weights.metadata) },
    { key: "pixel", label: "Pixel quality", score: input.pixelScore, weight: weights.pixel, contribution: input.pixelScore === null ? null : Math.round(input.pixelScore * weights.pixel) },
    { key: "alignment", label: "Alignment", score: input.alignmentScore, weight: weights.alignment, contribution: input.alignmentScore === null ? null : Math.round(input.alignmentScore * weights.alignment) },
    { key: "geometry", label: "Boundary evidence", score: input.edgeScore, weight: weights.geometry, contribution: input.edgeScore === null ? null : Math.round(input.edgeScore * weights.geometry) },
  ];
}

export type ConfidenceTrend = { current: number | null; previous: number | null; delta: number | null; label: string; guidance: string };

export function getConfidenceTrend(current: number | null, previous: number | null): ConfidenceTrend {
  if (current === null || previous === null) return { current, previous, delta: null, label: "Single capture", guidance: "Capture another image to compare confidence over time." };
  const delta = current - previous;
  if (delta >= 8) return { current, previous, delta, label: "Confidence improving", guidance: `Evidence confidence increased by ${delta} points versus the prior capture.` };
  if (delta <= -8) return { current, previous, delta, label: "Confidence declining", guidance: `Evidence confidence decreased by ${Math.abs(delta)} points; review framing, light, and boundaries.` };
  return { current, previous, delta, label: "Confidence stable", guidance: "Evidence confidence is stable versus the prior capture." };
}

export function getEvidenceConfidence(input: { metadataScore: number | null; pixelScore: number | null; alignmentScore: number | null; edgeScore: number | null }): EvidenceConfidenceResult {
  const scores = [input.metadataScore, input.pixelScore, input.alignmentScore, input.edgeScore].filter((score): score is number => typeof score === "number" && Number.isFinite(score));
  if (!scores.length) return { state: "unavailable", score: null, label: "Evidence confidence unavailable", guidance: "Use the framing guide and human review before analysis." };
  const score = Math.round(scores.reduce((sum, value) => sum + value, 0) / scores.length);
  const spread = Math.max(...scores) - Math.min(...scores);
  if (score >= 82 && spread <= 24) return { state: "high", score, label: "High evidence confidence", guidance: "Signals agree; confirm visible edges and continue to analysis." };
  if (score >= 62) return { state: "medium", score, label: "Review evidence confidence", guidance: spread > 30 ? "Signals disagree; check focus, lighting, and component boundaries before analysis." : "Evidence is usable, but confirm the component is fully visible." };
  return { state: "low", score, label: "Low evidence confidence", guidance: spread > 30 ? "Signals disagree; recapture with the component centered, straight-on, and evenly lit." : "Recapture with the component centered, straight-on, and evenly lit." };
}

export type InspectionPhotoMetadata = {
  uri: string;
  width?: number;
  height?: number;
  capturedAt: string;
  orientation?: string;
  fileSize?: number;
};

export type PhotoQualityResult = {
  state: PhotoQualityState;
  score: number | null;
  label: string;
  message: string;
  guidance: string;
};

export function getFramingState(quality: ScanQuality, zoom: number): { state: FramingState; label: string } {
  if (quality === "verification" && zoom <= 0.6) return { state: "clear", label: "Frame looks clear" };
  if (zoom > 0.6) return { state: "adjust", label: "Zoom out slightly" };
  return { state: "adjust", label: "Center the full code" };
}

export function getInspectionPhotoReadiness(photo: { uri?: string; width?: number; height?: number }): { ready: boolean; label: string; message: string } {
  if (!photo.uri) return { ready: false, label: "Capture unavailable", message: "No image was returned. Retry the capture without discarding the inspection." };
  if ((photo.width ?? 0) < 640 || (photo.height ?? 0) < 480) return { ready: false, label: "Improve image quality", message: "The image is too small for a reliable inspection. Move closer and recapture." };
  return { ready: true, label: "Image ready for review", message: "The image has enough local metadata for human review before analysis." };
}

export function getInspectionPhotoQuality(photo: { uri?: string; width?: number; height?: number; exif?: Record<string, unknown> | null; fileSize?: number }): PhotoQualityResult {
  if (!photo.uri) return { state: "improve", score: null, label: "Capture unavailable", message: "No image metadata was returned.", guidance: "Retry capture without discarding the inspection." };
  const width = photo.width ?? Number(photo.exif?.PixelXDimension ?? photo.exif?.ImageWidth ?? 0);
  const height = photo.height ?? Number(photo.exif?.PixelYDimension ?? photo.exif?.ImageLength ?? 0);
  const scoreParts = [width >= 1280 ? 40 : width >= 960 ? 30 : width >= 640 ? 20 : 0, height >= 960 ? 30 : height >= 720 ? 22 : height >= 480 ? 14 : 0, photo.fileSize && photo.fileSize >= 40_000 ? 20 : photo.fileSize ? 8 : 0, photo.exif ? 10 : 0];
  const score = scoreParts.reduce((total, value) => total + value, 0);
  if (width < 640 || height < 480) return { state: "improve", score, label: "Improve capture", message: "Resolution is below the local inspection threshold.", guidance: "Move closer, keep the component fully inside the frame, and recapture." };
  if (score < 65) return { state: "review", score, label: "Review image quality", message: "The photo is usable, but metadata is incomplete for a high-confidence quality signal.", guidance: "Check focus, glare, and component edges before analysis." };
  return { state: "ready", score, label: "Capture quality looks good", message: "Available metadata supports a quality-aware review.", guidance: "Keep the component centered and confirm the visible edges before analysis." };
}

export function getComponentAlignment(template: InspectionFrameTemplate, photo?: { width?: number; height?: number; exif?: Record<string, unknown> | null }): ComponentAlignmentResult {
  const width = photo?.width ?? 0;
  const height = photo?.height ?? 0;
  if (!width || !height) return { state: "unavailable", score: null, label: "Alignment unavailable", message: "Keep all component edges visible; alignment will be reviewed after capture." };
  const expected = INSPECTION_FRAME_TEMPLATES[template].aspectRatio;
  const ratio = width / height;
  const ratioDelta = Math.abs(ratio - expected) / expected;
  const orientation = String(photo?.exif?.Orientation ?? photo?.exif?.orientation ?? "");
  const orientationPenalty = orientation && /rotate|sideways|6|8/i.test(orientation) ? 12 : 0;
  const score = Math.max(0, Math.round(100 - Math.min(100, ratioDelta * 110) - orientationPenalty));
  if (score >= 82) return { state: "aligned", score, label: "Alignment looks good", message: `The ${INSPECTION_FRAME_TEMPLATES[template].label.toLowerCase()} ratio and orientation are consistent with the capture guide.` };
  if (score >= 62) return { state: "review", score, label: "Review alignment", message: "The component may be slightly tilted or cropped; confirm all edges and printed details before analysis." };
  return { state: "adjust", score, label: "Adjust perspective", message: `Reframe the ${INSPECTION_FRAME_TEMPLATES[template].label.toLowerCase()} straight-on and keep its full outline inside the guide.` };
}

export function getInspectionFrameTemplateGuidance(template: InspectionFrameTemplate, photo?: { width?: number; height?: number }): { label: string; message: string } {
  const definition = INSPECTION_FRAME_TEMPLATES[template];
  const ratio = photo?.width && photo.height ? photo.width / photo.height : 0;
  if (ratio && Math.abs(ratio - definition.aspectRatio) > 0.55) return { label: `Adjust ${definition.label.toLowerCase()} framing`, message: `${definition.detail} ${definition.guide}` };
  return { label: `${definition.label} template active`, message: `${definition.detail} ${definition.guide}` };
}

export function getInspectionFramingGuidance(photo?: { width?: number; height?: number }): { label: string; message: string } {
  const width = photo?.width ?? 0;
  const height = photo?.height ?? 0;
  if (!width || !height) return { label: "Frame the component", message: "Keep the full component inside the guide, with all inspection edges visible." };
  if (width / height > 1.9 || height / width > 1.9) return { label: "Adjust orientation", message: "Rotate or reframe so the component fills the center without cutting off its edges." };
  return { label: "Framing guide active", message: "Align the component inside the guide and leave a small margin around every edge." };
}

export function formatInspectionPhotoDiagnostics(photo: { width?: number; height?: number; fileSize?: number; exif?: Record<string, unknown> | null; capturedAt?: string; frameTemplate?: InspectionFrameTemplate; pixelBlurScore?: number | null; pixelExposureScore?: number | null; pixelConfidenceBand?: "high" | "medium" | "low"; pixelExplanation?: string; alignmentScore?: number | null; alignmentState?: ComponentAlignmentState }): string[] {
  const width = photo.width ?? 0;
  const height = photo.height ?? 0;
  const diagnostics: string[] = [];
  diagnostics.push(width && height ? `Resolution ${width} × ${height}` : "Resolution unavailable");
  diagnostics.push(width && height ? `Aspect ratio ${(width / height).toFixed(2)}:1` : "Aspect ratio unavailable");
  diagnostics.push(photo.exif ? "EXIF metadata available" : "EXIF metadata unavailable");
  diagnostics.push(photo.fileSize ? `File size ${(photo.fileSize / 1024).toFixed(0)} KB` : "File size unavailable");
  if (photo.capturedAt) diagnostics.push(`Captured ${new Date(photo.capturedAt).toLocaleString()}`);
  if (photo.frameTemplate) diagnostics.push(`Frame template ${INSPECTION_FRAME_TEMPLATES[photo.frameTemplate].label}`);
  if (photo.pixelBlurScore !== undefined) diagnostics.push(`Pixel blur score ${photo.pixelBlurScore ?? "unavailable"}`);
  if (photo.pixelExposureScore !== undefined) diagnostics.push(`Pixel exposure score ${photo.pixelExposureScore ?? "unavailable"}`);
  if (photo.pixelConfidenceBand) diagnostics.push(`Pixel confidence ${photo.pixelConfidenceBand}`);
  if (photo.pixelExplanation) diagnostics.push(`Pixel rationale: ${photo.pixelExplanation}`);
  if (photo.alignmentScore !== undefined) diagnostics.push(`Alignment score ${photo.alignmentScore ?? "unavailable"}`);
  if (photo.alignmentState) diagnostics.push(`Alignment state ${photo.alignmentState}`);
  return diagnostics;
}

export function getInspectionCaptureReadiness(confidence: number, evidence: string[]): { ready: boolean; label: string; message: string } {
  const hasQualityEvidence = evidence.some((item) => /image quality|component centered|component identified/i.test(item));
  if (confidence >= 90 && hasQualityEvidence) return { ready: true, label: "Capture ready", message: "Lighting and framing evidence meet the local inspection threshold." };
  if (!hasQualityEvidence) return { ready: false, label: "Improve capture", message: "Center the component and confirm image quality before analysis." };
  return { ready: false, label: "Review capture", message: "Capture confidence is below the recommended review threshold." };
}

export function formatScanSessionSummary(stats: { readable: number; verified: number; adjustments: number }): string {
  const attempts = `${stats.readable} readable ${stats.readable === 1 ? "attempt" : "attempts"}`;
  const verified = `${stats.verified} verified`;
  const adjustments = stats.adjustments > 0 ? ` · ${stats.adjustments} framing adjustment${stats.adjustments === 1 ? "" : "s"}` : "";
  return `${attempts} · ${verified}${adjustments}`;
}

export function getScanConfidenceLabel(quality: ScanQuality): string {
  if (quality === "verification") return "High confidence · verification payload";
  if (quality === "malformed") return "Low confidence · unsupported payload";
  return "Waiting for a readable code";
}

export const MIN_CAMERA_ZOOM = 0;
export const MAX_CAMERA_ZOOM = 0.8;

export function clampCameraZoom(value: number): number {
  if (!Number.isFinite(value)) return MIN_CAMERA_ZOOM;
  return Math.min(MAX_CAMERA_ZOOM, Math.max(MIN_CAMERA_ZOOM, Number(value.toFixed(2))));
}

export function getCaptureReadiness(torchEnabled: boolean, quality: ScanQuality, zoom: number): { state: CaptureReadiness; message: string } {
  if (quality === "verification") return { state: "ready", message: "Ready to verify. Hold steady for a moment." };
  if (!torchEnabled && quality === "empty") return { state: "needs-light", message: "Add light or enable the flashlight, then center the code inside the frame." };
  if (zoom > 0.6) return { state: "needs-centering", message: "Zoom is high. Keep the full code inside the frame before scanning." };
  return { state: "needs-centering", message: "Center the full code and keep the camera steady." };
}

export type ScanQualityResult = {
  quality: ScanQuality;
  normalizedValue: string;
  message: string;
};

export function classifyScanPayload(value: string): ScanQualityResult {
  const normalizedValue = value.trim();
  if (!normalizedValue) return { quality: "empty", normalizedValue: "", message: "No readable code detected. Center the QR code inside the frame." };
  if (/(?:inspection|verify|c)\/?[A-Z]{2,5}-\d+/i.test(normalizedValue)) return { quality: "verification", normalizedValue, message: "Verification code detected. Checking the local evidence record…" };
  return { quality: "malformed", normalizedValue, message: "A code was detected, but it is not an Evolve verification payload. Try a sharper, fully visible code." };
}

export function scanGuidance(torchEnabled: boolean, quality: ScanQuality): string {
  if (quality === "verification") return "Hold steady while the verification record is checked.";
  if (torchEnabled) return "Keep the code flat and centered inside the frame.";
  return "Improve lighting, avoid glare, and fill the frame with the QR code.";
}
