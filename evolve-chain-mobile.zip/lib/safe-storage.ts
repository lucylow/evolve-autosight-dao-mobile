import AsyncStorage from "@react-native-async-storage/async-storage";

export async function safeRead(key: string) {
  try {
    return { value: await AsyncStorage.getItem(key), error: null as Error | null };
  } catch (error) {
    return { value: null, error: error instanceof Error ? error : new Error("Storage read failed") };
  }
}

export async function safeWrite(key: string, value: string) {
  try {
    await AsyncStorage.setItem(key, value);
    return { ok: true, error: null as Error | null };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error : new Error("Storage write failed") };
  }
}

export async function safeRemove(keys: string[]) {
  try {
    await AsyncStorage.multiRemove(keys);
    return { ok: true, error: null as Error | null };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error : new Error("Storage removal failed") };
  }
}

export async function safeReadJson<T>(key: string): Promise<{ value: T | null; error: Error | null }> {
  const result = await safeRead(key);
  if (result.error || !result.value) return { value: null, error: result.error };
  try {
    return { value: JSON.parse(result.value) as T, error: null };
  } catch {
    return { value: null, error: new Error("Stored data is invalid") };
  }
}

export async function safeWriteJson(key: string, value: unknown): Promise<{ ok: boolean; error: Error | null }> {
  try {
    return await safeWrite(key, JSON.stringify(value));
  } catch {
    return { ok: false, error: new Error("Data could not be serialized") };
  }
}
