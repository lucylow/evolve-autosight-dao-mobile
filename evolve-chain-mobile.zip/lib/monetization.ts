export type MonetizationPlan = "community" | "operations" | "network";
export type MonetizationFeature = "inspectionCapture" | "auditExports" | "teamCalibration" | "advancedTriage";

export type PlanDefinition = {
  id: MonetizationPlan;
  label: string;
  positioning: string;
  cta: string;
  features: Record<MonetizationFeature, boolean>;
};

export const PLAN_DEFINITIONS: PlanDefinition[] = [
  {
    id: "community",
    label: "Community",
    positioning: "Start with local inspection evidence and human review.",
    cta: "Current plan",
    features: { inspectionCapture: true, auditExports: false, teamCalibration: false, advancedTriage: false },
  },
  {
    id: "operations",
    label: "Operations",
    positioning: "Coordinate repeatable inspection workflows with stronger audit operations.",
    cta: "Explore Operations",
    features: { inspectionCapture: true, auditExports: true, teamCalibration: true, advancedTriage: true },
  },
  {
    id: "network",
    label: "Network",
    positioning: "Extend verified quality workflows across partners and manufacturing programs.",
    cta: "Talk to Evolve",
    features: { inspectionCapture: true, auditExports: true, teamCalibration: true, advancedTriage: true },
  },
];

export function isFeatureEntitled(plan: MonetizationPlan, feature: MonetizationFeature): boolean {
  return PLAN_DEFINITIONS.find((item) => item.id === plan)?.features[feature] ?? false;
}

export function getUpgradeMessage(feature: MonetizationFeature): string {
  if (feature === "auditExports") return "Upgrade to Operations to export privacy-safe quality summaries for external review.";
  if (feature === "teamCalibration") return "Team calibration profiles help align component thresholds across operators.";
  if (feature === "advancedTriage") return "Advanced triage organizes recurring quality issues for faster team review.";
  return "Your current plan includes local inspection capture and human review.";
}

export function getFeatureLabel(feature: MonetizationFeature): string {
  return { inspectionCapture: "Inspection capture", auditExports: "Audit exports", teamCalibration: "Team calibration", advancedTriage: "Advanced triage" }[feature];
}
