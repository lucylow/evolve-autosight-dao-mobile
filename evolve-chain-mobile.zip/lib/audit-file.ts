export const AUDIT_EXPORT_SCHEMA_VERSION = 1 as const;

export type AuditExportFormat = "json" | "csv";

export type AuditExportRecord = {
  record: string;
  state: string;
  time: string;
  outcome: "synced" | "failed" | "queued";
  network: string;
  acknowledgementId: string;
  detail: string;
  nextAttemptAt?: string;
  retryCountdown?: string;
};

export type AuditExportEnvelope = {
  schemaVersion: typeof AUDIT_EXPORT_SCHEMA_VERSION;
  exportedAt: string;
  exportFileName: string;
  dateRange: string;
  eventFilter: string;
  records: AuditExportRecord[];
  manifest?: { activityIds: string[]; acknowledgementIds: string[] };

};

export type AuditValidationResult = {
  valid: boolean;
  format?: AuditExportFormat;
  recordCount: number;
  message: string;
  envelope?: AuditExportEnvelope;
};

const REQUIRED_COLUMNS = [
  "record",
  "state",
  "time",
  "outcome",
  "network",
  "acknowledgementId",
  "detail",
] as const;
const OPTIONAL_COLUMNS = ["nextAttemptAt", "retryCountdown"] as const;

function isRecord(value: unknown): value is AuditExportRecord {
  if (!value || typeof value !== "object") return false;
  const row = value as Partial<AuditExportRecord>;
  return typeof row.record === "string" && row.record.length > 0
    && typeof row.state === "string" && row.state.length > 0
    && typeof row.time === "string" && row.time.length > 0
    && (row.outcome === "synced" || row.outcome === "failed" || row.outcome === "queued")
    && typeof row.network === "string" && row.network.length > 0
    && typeof row.acknowledgementId === "string" && row.acknowledgementId.length > 0
    && typeof row.detail === "string";
}

function validateEnvelope(value: unknown): AuditValidationResult {
  if (!value || typeof value !== "object") {
    return { valid: false, recordCount: 0, message: "The JSON root must be an audit export object." };
  }
  const candidate = value as Partial<AuditExportEnvelope>;
  const records = candidate.records;
  if (candidate.schemaVersion !== AUDIT_EXPORT_SCHEMA_VERSION) {
    return { valid: false, recordCount: Array.isArray(records) ? records.length : 0, message: "Unsupported or missing audit schema version." };
  }
  if (typeof candidate.exportedAt !== "string" || candidate.exportedAt.length === 0 || typeof candidate.exportFileName !== "string" || candidate.exportFileName.length === 0 || typeof candidate.dateRange !== "string" || candidate.dateRange.length === 0 || typeof candidate.eventFilter !== "string" || candidate.eventFilter.length === 0) {
    return { valid: false, recordCount: Array.isArray(records) ? records.length : 0, message: "Audit export metadata is incomplete." };
  }
  if (!Array.isArray(records) || records.some((record) => !isRecord(record))) {
    return { valid: false, recordCount: Array.isArray(records) ? records.length : 0, message: "One or more audit records failed integrity validation." };
  }
  const envelope = candidate as AuditExportEnvelope;
  return { valid: true, format: "json", recordCount: records.length, message: `Validated ${records.length} audit record${records.length === 1 ? "" : "s"}.`, envelope };
}

function parseCsvLine(line: string): string[] {
  const values: string[] = [];
  let current = "";
  let quoted = false;
  for (let index = 0; index < line.length; index += 1) {
    const character = line[index];
    if (character === '"') {
      if (quoted && line[index + 1] === '"') { current += '"'; index += 1; } else quoted = !quoted;
    } else if (character === "," && !quoted) {
      values.push(current); current = "";
    } else current += character;
  }
  values.push(current);
  return values;
}

export function validateAuditJsonText(text: string): AuditValidationResult {
  try {
    return validateEnvelope(JSON.parse(text));
  } catch {
    return { valid: false, format: "json", recordCount: 0, message: "The JSON file is not parseable." };
  }
}

export function validateAuditCsvText(text: string): AuditValidationResult {
  const lines = text.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  const headerIndex = lines.findIndex((line) => line === REQUIRED_COLUMNS.join(",") || line === [...REQUIRED_COLUMNS, ...OPTIONAL_COLUMNS].join(","));
  if (headerIndex < 0) return { valid: false, format: "csv", recordCount: 0, message: "CSV header is missing or does not match the audit schema." };
  const columns = lines[headerIndex] === [...REQUIRED_COLUMNS, ...OPTIONAL_COLUMNS].join(",") ? [...REQUIRED_COLUMNS, ...OPTIONAL_COLUMNS] : REQUIRED_COLUMNS;
  const records = lines.slice(headerIndex + 1).map((line) => {
    const values = parseCsvLine(line);
    return Object.fromEntries(columns.map((column, index) => [column, values[index] ?? ""])) as unknown as AuditExportRecord;
  });
  if (records.some((record) => !isRecord(record))) return { valid: false, format: "csv", recordCount: records.length, message: "One or more CSV rows failed integrity validation." };
  const metadata = Object.fromEntries(lines.slice(0, headerIndex).filter((line) => line.startsWith("# ")).map((line) => {
    const separator = line.indexOf("=");
    return separator > 0 ? [line.slice(2, separator), line.slice(separator + 1)] : ["", ""];
  }));
  if (metadata.schemaVersion !== String(AUDIT_EXPORT_SCHEMA_VERSION) || !metadata.exportFileName || !metadata.exportedAt || !metadata.dateRange || !metadata.eventFilter) {
    return { valid: false, format: "csv", recordCount: records.length, message: "CSV export metadata is incomplete or invalid." };
  }
  const envelope: AuditExportEnvelope = { schemaVersion: AUDIT_EXPORT_SCHEMA_VERSION, exportedAt: metadata.exportedAt, exportFileName: metadata.exportFileName, dateRange: metadata.dateRange, eventFilter: metadata.eventFilter, records, manifest: { activityIds: (metadata.activityIds ?? "").split("|").filter(Boolean), acknowledgementIds: (metadata.acknowledgementIds ?? "").split("|").filter(Boolean) } };
  return { valid: true, format: "csv", recordCount: records.length, message: `Validated ${records.length} audit record${records.length === 1 ? "" : "s"}.`, envelope };
}

export function validateAuditFileText(text: string, format?: AuditExportFormat): AuditValidationResult {
  const normalized = text.trim();
  if (!normalized) return { valid: false, recordCount: 0, message: "The selected audit file is empty." };
  if (format === "csv" || normalized.startsWith("# Evolve Insight Audit Export")) return validateAuditCsvText(normalized);
  return validateAuditJsonText(normalized);
}
