export type Initiative = {
  id: string;
  category: "Governance" | "Mission" | "Verification";
  title: string;
  summary: string;
  status: "Active" | "Voting" | "Verified";
  metric: string;
  metricLabel: string;
  accent: "cyan" | "violet" | "green";
};

export type Proposal = {
  id: string;
  title: string;
  summary: string;
  status: "Voting" | "Queued" | "Executed";
  deadline: string;
  support: string;
};

export const initiatives: Initiative[] = [
  {
    id: "proof-of-quality",
    category: "Verification",
    title: "Proof of Quality",
    summary: "Anchor inspection evidence so partners can verify the record without exposing private manufacturing data.",
    status: "Active",
    metric: "1,284",
    metricLabel: "records anchored",
    accent: "cyan",
  },
  {
    id: "supplier-attestations",
    category: "Mission",
    title: "Supplier Attestations",
    summary: "Build a trusted network of supplier credentials, batch attestations, and verifiable corrective actions.",
    status: "Active",
    metric: "18",
    metricLabel: "organizations",
    accent: "violet",
  },
  {
    id: "dao-quality-council",
    category: "Governance",
    title: "DAO Quality Council",
    summary: "Coordinate the next set of open standards for transparent, AI-assisted quality operations.",
    status: "Voting",
    metric: "72%",
    metricLabel: "community support",
    accent: "green",
  },
];

export const proposals: Proposal[] = [
  {
    id: "prop-014",
    title: "Adopt the Evolve Evidence Standard",
    summary: "Create a shared format for inspection evidence hashes, human approvals, and verification status.",
    status: "Voting",
    deadline: "Closes in 2d 14h",
    support: "72% support",
  },
  {
    id: "prop-013",
    title: "Launch the Supplier Credential Pilot",
    summary: "Invite five manufacturing partners to test verifiable credentials for certificates and attestations.",
    status: "Queued",
    deadline: "Execution scheduled",
    support: "89% support",
  },
  {
    id: "prop-012",
    title: "Fund AutoSight Research Grants",
    summary: "Allocate a community pool for open research into visual inspection and predictive quality workflows.",
    status: "Executed",
    deadline: "Executed Aug 14",
    support: "91% support",
  },
];

export type InspectionStage = "ready" | "capturing" | "analyzing" | "review" | "approved";

export type InspectionRecord = {
  id: string;
  partNumber: string;
  partName: string;
  batch: string;
  classification: "Surface anomaly" | "Pass";
  confidence: number;
  severity: "Medium" | "Low";
  explanation: string;
  recommendation: string;
  evidence: string[];
};

export const inspections: InspectionRecord[] = [
  {
    id: "INS-10293",
    partNumber: "EV-39281",
    partName: "Precision Transmission Housing",
    batch: "B-49281",
    classification: "Surface anomaly",
    confidence: 94,
    severity: "Medium",
    explanation: "The visual pattern differs from the approved surface reference and resembles two previously documented anomalies.",
    recommendation: "Review the highlighted region and compare against the current surface specification before approval.",
    evidence: ["Component centered", "Image quality passed", "2 similar anomalies found"],
  },
  {
    id: "INS-10288",
    partNumber: "EV-18422",
    partName: "Brake Caliper Mount",
    batch: "B-18422",
    classification: "Pass",
    confidence: 98,
    severity: "Low",
    explanation: "No material visual deviation was detected against the approved incoming specification.",
    recommendation: "Approve this inspection after human confirmation.",
    evidence: ["Component identified", "Label matched", "Specification aligned"],
  },
];

export const INSPECTION_APPROVALS_KEY = "evolve-insight:inspection-approvals";
export const INSPECTION_CAPTURE_METADATA_KEY = "evolve-insight:inspection-capture-metadata";
export const INSPECTION_CAPTURE_HISTORY_KEY = "evolve-insight:inspection-capture-history";

export type InspectionFrameTemplate = "housing" | "label" | "flat-surface";

export type InspectionCaptureMetadata = {
  uri: string;
  width?: number;
  height?: number;
  capturedAt: string;
  qualityState: "ready" | "review" | "improve";
  qualityScore: number | null;
  qualityLabel: string;
  pixelBlurScore?: number | null;
  pixelExposureScore?: number | null;
  pixelConfidenceBand?: "high" | "medium" | "low";
  pixelExplanation?: string;
  alignmentScore?: number | null;
  alignmentState?: "aligned" | "review" | "adjust" | "unavailable";
  edgeScore?: number | null;
  geometryState?: "strong" | "review" | "weak" | "unavailable";
  geometryExplanation?: string;
  evidenceConfidenceScore?: number | null;
  evidenceConfidenceState?: "high" | "medium" | "low" | "unavailable";
  evidenceConfidenceGuidance?: string;
  confidenceTrendLabel?: string;
  confidenceTrendDelta?: number | null;
  confidenceTrendGuidance?: string;
  calibrationSummary?: string;
  operatorReviewReason?: string;
  operatorReviewCategory?: "blur" | "exposure" | "alignment" | "occlusion" | "signal-conflict" | "metadata-gap";
  triageLabel?: string;
  frameTemplate?: InspectionFrameTemplate;
};

export const OPERATOR_ACTIVITY_KEY = "evolve-insight:operator-activity";
export type OperatorActivity = {
  id: string;
  time: string;
  kind: "batch-retry" | "audit-import";
  summary: string;
  detail: string;
};

export type VerificationState = "Verified" | "Pending anchor" | "Needs review";

export type AuditEvent = {
  label: string;
  detail: string;
  timestamp: string;
  state: "complete" | "current" | "pending";
};

export const inspectionVerification: Record<string, { state: VerificationState; hash: string; network: string; anchoredAt: string; events: AuditEvent[] }> = {
  "INS-10293": {
    state: "Pending anchor",
    hash: "0x7b4d…91af",
    network: "Evolve testnet",
    anchoredAt: "Awaiting human approval",
    events: [
      { label: "Evidence captured", detail: "Original inspection image stored", timestamp: "09:42", state: "complete" },
      { label: "AI analysis completed", detail: "EVOLVE Vision · model 2026.08", timestamp: "09:43", state: "complete" },
      { label: "Human review", detail: "Inspector decision required", timestamp: "Now", state: "current" },
      { label: "Evidence anchor", detail: "Hash will be published after approval", timestamp: "Pending", state: "pending" },
    ],
  },
  "INS-10288": {
    state: "Verified",
    hash: "0x19ac…3e42",
    network: "Evolve testnet",
    anchoredAt: "Aug 18, 2026 · 09:19",
    events: [
      { label: "Evidence captured", detail: "Original inspection image stored", timestamp: "09:18", state: "complete" },
      { label: "AI analysis completed", detail: "EVOLVE Vision · model 2026.08", timestamp: "09:18", state: "complete" },
      { label: "Human review approved", detail: "Quality decision recorded", timestamp: "09:19", state: "complete" },
      { label: "Evidence anchor", detail: "Hash published to Evolve testnet", timestamp: "09:19", state: "complete" },
    ],
  },
};

export const SCAN_HISTORY_KEY = "evolve-insight:scan-history";

export const SCAN_LAST_SYNC_KEY = "evolve-insight:scan-last-sync";
