export type PixelQualityState = "good" | "review" | "poor" | "unavailable";

export type PixelQualityResult = {
  state: PixelQualityState;
  blurScore: number | null;
  exposureScore: number | null;
  confidenceBand: "high" | "medium" | "low";
  label: string;
  message: string;
  explanation: string;
  edgeScore: number | null;
  geometryState: "strong" | "review" | "weak" | "unavailable";
  geometryExplanation: string;
};

export type PixelSample = { luminance: number; x?: number; y?: number };
export type PixelRegion = { x: number; y: number; width: number; height: number };

export const PIXEL_REGIONS: Record<"housing" | "label" | "flat-surface", PixelRegion> = {
  housing: { x: 0.1, y: 0.1, width: 0.8, height: 0.8 },
  label: { x: 0.08, y: 0.25, width: 0.84, height: 0.5 },
  "flat-surface": { x: 0.1, y: 0.1, width: 0.8, height: 0.8 },
};

export function estimatePixelQuality(samples: PixelSample[], region?: PixelRegion): PixelQualityResult {
  const regionSamples = region ? samples.filter((sample) => sample.x === undefined || sample.y === undefined || (sample.x >= region.x && sample.x <= region.x + region.width && sample.y >= region.y && sample.y <= region.y + region.height)) : samples;
  if (regionSamples.length < 16) return { state: "unavailable", blurScore: null, exposureScore: null, confidenceBand: "low", label: "Pixel quality unavailable", message: "The image could not provide enough safe pixel samples; use the metadata review instead.", explanation: "No pixel-level conclusion was made because the evidence sample was incomplete.", edgeScore: null, geometryState: "unavailable", geometryExplanation: "Geometric evidence is unavailable until enough pixels can be sampled." };
  const luminance = regionSamples.map((sample) => Math.max(0, Math.min(255, sample.luminance)));
  const mean = luminance.reduce((sum, value) => sum + value, 0) / luminance.length;
  const variance = luminance.reduce((sum, value) => sum + (value - mean) ** 2, 0) / luminance.length;
  const exposureScore = Math.round(Math.max(0, 100 - Math.abs(mean - 128) * 0.78));
  const blurScore = Math.round(Math.min(100, Math.sqrt(variance) * 1.55));
  const edgeEnergy = regionSamples.slice(1).reduce((sum, sample, index) => sum + Math.abs(sample.luminance - regionSamples[index].luminance), 0) / Math.max(1, regionSamples.length - 1);
  const edgeScore = Math.round(Math.min(100, edgeEnergy * 1.25));
  const geometryState = edgeScore >= 48 ? "strong" : edgeScore >= 22 ? "review" : "weak";
  const state = blurScore < 18 || exposureScore < 42 ? "poor" : blurScore < 30 || exposureScore < 68 ? "review" : "good";
  const confidenceBand = luminance.length >= 128 ? "high" : luminance.length >= 48 ? "medium" : "low";
  const blurExplanation = blurScore < 30 ? "low local luminance variation may indicate blur" : "local luminance variation supports visible texture";
  const exposureExplanation = exposureScore < 68 ? mean < 128 ? "the sampled image may be underexposed" : "the sampled image may be overexposed" : "sampled brightness is near the target range";
  const issues = [blurScore < 30 ? "possible blur" : "texture variation detected", exposureScore < 68 ? mean < 128 ? "underexposure" : "overexposure" : "balanced exposure"];
  const geometryExplanation = geometryState === "strong" ? "edge transitions are distinct enough to support boundary review" : geometryState === "review" ? "edge transitions are mixed; confirm component boundaries manually" : "edge transitions are weak; perspective and boundaries may be difficult to verify";
  return { state, blurScore, exposureScore, confidenceBand, label: state === "good" ? "Pixel quality looks good" : state === "review" ? "Review pixel quality" : "Improve pixel quality", message: `${issues[0]} · ${issues[1]}.`, explanation: `${blurExplanation}; ${exposureExplanation}.`, edgeScore, geometryState, geometryExplanation };
}
