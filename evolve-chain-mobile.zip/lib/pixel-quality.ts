import * as FileSystem from "expo-file-system/legacy";
import { estimatePixelQuality, PIXEL_REGIONS, type PixelQualityResult, type PixelSample } from "@/lib/pixel-metrics";
import type { InspectionFrameTemplate } from "@/lib/evolve-data";
export type { PixelQualityResult } from "@/lib/pixel-metrics";

// jpeg-js is CommonJS; require keeps Expo Metro and Vitest interop stable.
const jpeg = require("jpeg-js") as { decode: (data: Uint8Array, options: { useTArray: true }) => { width: number; height: number; data: Uint8Array } };

function base64ToBytes(value: string): Uint8Array {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  const clean = value.replace(/[^A-Za-z0-9+/=]/g, "");
  const bytes = new Uint8Array(Math.max(0, Math.floor((clean.length * 3) / 4) - (clean.endsWith("==") ? 2 : clean.endsWith("=") ? 1 : 0)));
  let buffer = 0;
  let bits = 0;
  let index = 0;
  for (const character of clean) {
    if (character === "=") break;
    buffer = (buffer << 6) | alphabet.indexOf(character);
    bits += 6;
    if (bits >= 8) { bits -= 8; bytes[index++] = (buffer >> bits) & 0xff; }
  }
  return bytes;
}

export async function estimateJpegPixelQuality(uri: string, frameTemplate: InspectionFrameTemplate = "housing", sampleLimit = 1024): Promise<PixelQualityResult> {
  try {
    if (!uri || uri.startsWith("data:")) return { state: "unavailable", blurScore: null, exposureScore: null, confidenceBand: "low", label: "Pixel quality unavailable", message: "This image URI is not a local JPEG file.", explanation: "No pixel-level conclusion was made because the URI was not a readable local JPEG.", edgeScore: null, geometryState: "unavailable", geometryExplanation: "Geometric evidence is unavailable because the image could not be decoded." };
    const base64 = await FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
    const decoded = jpeg.decode(base64ToBytes(base64), { useTArray: true });
    const samples: PixelSample[] = [];
    const stride = Math.max(1, Math.floor((decoded.width * decoded.height) / sampleLimit));
    for (let pixelIndex = 0; pixelIndex < decoded.width * decoded.height && samples.length < sampleLimit; pixelIndex += stride) {
      const offset = pixelIndex * 4;
      samples.push({ luminance: decoded.data[offset] * 0.2126 + decoded.data[offset + 1] * 0.7152 + decoded.data[offset + 2] * 0.0722, x: (pixelIndex % decoded.width) / decoded.width, y: Math.floor(pixelIndex / decoded.width) / decoded.height });
    }
    return estimatePixelQuality(samples, PIXEL_REGIONS[frameTemplate]);
  } catch {
    return { state: "unavailable", blurScore: null, exposureScore: null, confidenceBand: "low", label: "Pixel quality unavailable", message: "Pixel sampling failed safely; continue with metadata and human review.", explanation: "Pixel decoding failed safely; metadata and human review remain authoritative.", edgeScore: null, geometryState: "unavailable", geometryExplanation: "Geometric evidence failed safely; use metadata and human review." };
  }
}
