import { useMemo, useState } from "react";
import { useRouter } from "expo-router";
import { FlatList, Pressable, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { initiatives, type Initiative } from "@/lib/evolve-data";
import { useColors } from "@/hooks/use-colors";

const filters = ["All", "Governance", "Mission", "Verification"] as const;
type Filter = (typeof filters)[number];

export default function ExploreScreen() {
  const colors = useColors();
  const router = useRouter();
  const [filter, setFilter] = useState<Filter>("All");
  const filtered = useMemo(() => filter === "All" ? initiatives : initiatives.filter((item) => item.category === filter), [filter]);

  return (
    <ScreenContainer className="px-5 pt-5">
      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}
        ListHeaderComponent={<View>
          <Text style={[styles.eyebrow, { color: colors.primary }]}>ECOSYSTEM</Text>
          <Text style={[styles.title, { color: colors.foreground }]}>Explore what’s evolving</Text>
          <Text style={[styles.subtitle, { color: colors.muted }]}>Initiatives, standards, and governance signals shaping trusted manufacturing.</Text>
          <View style={styles.filterRow}>
            {filters.map((value) => <Pressable accessibilityRole="button" accessibilityState={{ selected: filter === value }} accessibilityLabel={`Filter initiatives by ${value}`} key={value} onPress={() => setFilter(value)} style={({ pressed }) => [styles.filter, { backgroundColor: filter === value ? colors.primary : colors.surface, borderColor: filter === value ? colors.primary : colors.border }, pressed && { transform: [{ scale: 0.97 }], opacity: 0.78 }]}><Text style={[styles.filterText, { color: filter === value ? colors.background : colors.muted }]}>{value}</Text></Pressable>)}
          </View>
          <View style={styles.resultHeader}><Text style={[styles.sectionTitle, { color: colors.foreground }]}>Active initiatives</Text><Text style={[styles.resultCount, { color: colors.muted }]}>{filtered.length} signals</Text></View>
        </View>}
        renderItem={({ item }) => <InitiativeCard item={item} />}
      />
    </ScreenContainer>
  );

  function InitiativeCard({ item }: { item: Initiative }) {
    const accent = item.accent === "violet" ? "#9B8AFB" : item.accent === "green" ? colors.success : colors.primary;
    return <Pressable accessibilityRole="button" accessibilityLabel={`Open initiative ${item.title}`} onPress={() => router.push((`/initiative/${item.id}`) as any)} style={({ pressed }) => [styles.card, { backgroundColor: colors.surface, borderColor: colors.border }, pressed && styles.pressed]}>
      <View style={styles.cardHeader}><View style={[styles.iconBox, { backgroundColor: `${accent}1A` }]}><IconSymbol name={item.category === "Verification" ? "shield.fill" : item.category === "Governance" ? "checkmark.seal.fill" : "sparkles"} size={20} color={accent} /></View><View style={[styles.status, { backgroundColor: `${accent}18` }]}><Text style={[styles.statusText, { color: accent }]}>{item.status}</Text></View></View>
      <Text style={[styles.cardTitle, { color: colors.foreground }]}>{item.title}</Text>
      <Text style={[styles.cardSummary, { color: colors.muted }]}>{item.summary}</Text>
      <View style={[styles.cardFooter, { borderTopColor: colors.border }]}><Text style={[styles.metric, { color: colors.foreground }]}>{item.metric}</Text><Text style={[styles.metricLabel, { color: colors.muted }]}>{item.metricLabel}</Text><IconSymbol name="chevron.right" size={19} color={colors.muted} /></View>
    </Pressable>;
  }
}

const styles = StyleSheet.create({
  content: { paddingBottom: 30 },
  eyebrow: { fontSize: 12, letterSpacing: 1.6, fontWeight: "800", marginBottom: 8 },
  title: { fontSize: 29, lineHeight: 35, fontWeight: "800", letterSpacing: -0.8, marginBottom: 8 },
  subtitle: { fontSize: 14, lineHeight: 21, marginBottom: 21 },
  filterRow: { flexDirection: "row", gap: 7, marginBottom: 25 },
  filter: { borderWidth: 1, borderRadius: 999, minHeight: 38, paddingHorizontal: 13, paddingVertical: 8, justifyContent: "center" },
  filterText: { fontSize: 12, fontWeight: "700" },
  resultHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 12 },
  sectionTitle: { fontSize: 17, fontWeight: "800" },
  resultCount: { fontSize: 12 },
  card: { borderRadius: 20, borderWidth: 1, padding: 17, marginBottom: 12, shadowColor: "#101828", shadowOpacity: 0.045, shadowRadius: 11, shadowOffset: { width: 0, height: 5 }, elevation: 2 },
  cardHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 15 },
  iconBox: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  status: { borderRadius: 10, paddingHorizontal: 10, paddingVertical: 6 },
  statusText: { fontSize: 11, fontWeight: "800" },
  cardTitle: { fontSize: 19, fontWeight: "800", marginBottom: 7 },
  cardSummary: { fontSize: 14, lineHeight: 21, marginBottom: 16 },
  cardFooter: { flexDirection: "row", alignItems: "center", gap: 7, paddingTop: 13, borderTopWidth: 1 },
  metric: { fontSize: 16, fontWeight: "800" },
  metricLabel: { fontSize: 12, flex: 1 },
  pressed: { opacity: 0.72, transform: [{ scale: 0.99 }] },
});
