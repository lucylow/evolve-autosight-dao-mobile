import { useRouter } from "expo-router";
import { FlatList, Pressable, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { initiatives } from "@/lib/evolve-data";
import { useColors } from "@/hooks/use-colors";

const metrics = [
  { value: "06", label: "active proposals", icon: "checkmark.seal.fill" as const },
  { value: "18", label: "trusted partners", icon: "person.crop.circle.fill" as const },
  { value: "98.4%", label: "network health", icon: "shield.fill" as const },
];

export default function HomeScreen() {
  const colors = useColors();
  const router = useRouter();

  return (
    <ScreenContainer className="px-5 pt-5" containerClassName="bg-background">
      <FlatList
        data={initiatives.slice(0, 2)}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}
        ListHeaderComponent={
          <View>
            <View style={styles.headerRow}>
              <View>
                <Text style={[styles.eyebrow, { color: colors.primary }]}>EVOLVE INSIGHT</Text>
                <Text style={[styles.title, { color: colors.foreground }]}>Good morning, Alex</Text>
              </View>
              <View style={[styles.statusPill, { backgroundColor: `${colors.success}18` }]}>
                <View style={[styles.statusDot, { backgroundColor: colors.success }]} />
                <Text style={[styles.statusText, { color: colors.success }]}>Live</Text>
              </View>
            </View>

            <View style={[styles.heroCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <View style={styles.heroTopline}>
                <View style={[styles.sparkle, { backgroundColor: `${colors.primary}22` }]}>
                  <IconSymbol name="sparkles" size={19} color={colors.primary} />
                </View>
                <Text style={[styles.cardLabel, { color: colors.muted }]}>AUTOSIGHT SIGNAL</Text>
              </View>
              <Text style={[styles.heroTitle, { color: colors.foreground }]}>The network is evolving.</Text>
              <Text style={[styles.heroBody, { color: colors.muted }]}>Quality evidence is moving from isolated records to a shared, verifiable layer.</Text>
              <Pressable accessibilityRole="button" accessibilityLabel="Explore the signal" accessibilityHint="Opens the Explore initiatives surface" onPress={() => router.push("/explore")} style={({ pressed }) => [styles.heroAction, { backgroundColor: colors.primary }, pressed && styles.pressed]}>
                <Text style={[styles.heroActionText, { color: colors.background }]}>Explore the signal</Text>
                <IconSymbol name="arrow.up.right" size={17} color={colors.background} />
              </Pressable>
            </View>

            <View style={styles.sectionHeader}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Network pulse</Text>
              <Text style={[styles.sectionMeta, { color: colors.muted }]}>Today</Text>
            </View>
            <View style={styles.metricGrid}>
              {metrics.map((metric) => (
                <View key={metric.label} style={[styles.metricCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                  <IconSymbol name={metric.icon} size={18} color={colors.primary} />
                  <Text style={[styles.metricValue, { color: colors.foreground }]}>{metric.value}</Text>
                  <Text style={[styles.metricLabel, { color: colors.muted }]}>{metric.label}</Text>
                </View>
              ))}
            </View>

            <View style={styles.sectionHeader}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Continue exploring</Text>
              <Pressable accessibilityRole="button" accessibilityLabel="See all initiatives" onPress={() => router.push("/explore")}><Text style={[styles.seeAll, { color: colors.primary }]}>See all</Text></Pressable>
            </View>
          </View>
        }
        renderItem={({ item }) => (
          <Pressable accessibilityRole="button" accessibilityLabel={`Open initiative ${item.title}`} onPress={() => router.push((`/initiative/${item.id}`) as any)} style={({ pressed }) => [styles.initiativeCard, { backgroundColor: colors.surface, borderColor: colors.border }, pressed && styles.pressed]}>
            <View style={[styles.accentBar, { backgroundColor: item.accent === "violet" ? "#9B8AFB" : item.accent === "green" ? colors.success : colors.primary }]} />
            <View style={styles.initiativeMain}>
              <View style={styles.cardRow}>
                <Text style={[styles.category, { color: colors.muted }]}>{item.category.toUpperCase()}</Text>
                <Text style={[styles.active, { color: item.status === "Voting" ? colors.warning : colors.success }]}>{item.status}</Text>
              </View>
              <Text style={[styles.initiativeTitle, { color: colors.foreground }]}>{item.title}</Text>
              <Text style={[styles.initiativeSummary, { color: colors.muted }]} numberOfLines={2}>{item.summary}</Text>
            </View>
            <IconSymbol name="chevron.right" size={20} color={colors.muted} />
          </Pressable>
        )}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingBottom: 36 },
  headerRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 22 },
  eyebrow: { fontSize: 12, letterSpacing: 1.6, fontWeight: "800", marginBottom: 7 },
  title: { fontSize: 28, lineHeight: 34, fontWeight: "800", letterSpacing: -0.7 },
  statusPill: { flexDirection: "row", alignItems: "center", gap: 6, borderRadius: 999, paddingHorizontal: 11, paddingVertical: 7 },
  statusDot: { width: 7, height: 7, borderRadius: 4 },
  statusText: { fontSize: 12, fontWeight: "700" },
  heroCard: { borderRadius: 24, borderWidth: 1, padding: 20, marginBottom: 25 },
  heroTopline: { flexDirection: "row", alignItems: "center", gap: 9, marginBottom: 16 },
  sparkle: { width: 32, height: 32, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  cardLabel: { fontSize: 11, letterSpacing: 1.4, fontWeight: "800" },
  heroTitle: { fontSize: 22, lineHeight: 28, fontWeight: "800", marginBottom: 8 },
  heroBody: { fontSize: 14, lineHeight: 21, marginBottom: 19 },
  heroAction: { minHeight: 46, borderRadius: 14, paddingHorizontal: 16, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  heroActionText: { fontSize: 14, fontWeight: "800" },
  sectionHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 12, marginTop: 2 },
  sectionTitle: { fontSize: 17, fontWeight: "800" },
  sectionMeta: { fontSize: 12, fontWeight: "600" },
  seeAll: { fontSize: 13, fontWeight: "800" },
  metricGrid: { flexDirection: "row", gap: 9, marginBottom: 26 },
  metricCard: { flex: 1, borderRadius: 16, borderWidth: 1, padding: 11, minHeight: 104 },
  metricValue: { fontSize: 20, fontWeight: "800", marginTop: 12, marginBottom: 4 },
  metricLabel: { fontSize: 11, lineHeight: 15 },
  initiativeCard: { flexDirection: "row", alignItems: "center", borderRadius: 18, borderWidth: 1, marginBottom: 10, padding: 14, overflow: "hidden" },
  accentBar: { width: 4, alignSelf: "stretch", borderRadius: 2, marginRight: 12 },
  initiativeMain: { flex: 1 },
  cardRow: { flexDirection: "row", justifyContent: "space-between", marginBottom: 7 },
  category: { fontSize: 10, fontWeight: "800", letterSpacing: 1.1 },
  active: { fontSize: 11, fontWeight: "800" },
  initiativeTitle: { fontSize: 16, fontWeight: "800", marginBottom: 5 },
  initiativeSummary: { fontSize: 13, lineHeight: 18 },
  pressed: { opacity: 0.72, transform: [{ scale: 0.99 }] },
});
