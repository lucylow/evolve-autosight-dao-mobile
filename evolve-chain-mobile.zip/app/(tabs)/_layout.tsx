import { Tabs } from "expo-router";
import { Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { HapticTab } from "@/components/haptic-tab";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";

export default function TabLayout() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const bottomPadding = Platform.OS === "web" ? 12 : Math.max(insets.bottom, 8);

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.muted,
        tabBarButton: HapticTab,
        tabBarStyle: {
          height: 70 + bottomPadding,
          paddingTop: 6,
          paddingBottom: bottomPadding,
          backgroundColor: colors.background,
          borderTopColor: colors.border,
          borderTopWidth: 0.5,
        },
          tabBarLabelStyle: { fontSize: 11, lineHeight: 14, fontWeight: "700", marginTop: 1, marginBottom: 1 },
          tabBarIconStyle: { marginTop: 1 },
          tabBarItemStyle: { minHeight: 54, borderRadius: 14, marginHorizontal: 3, marginVertical: 3 },
          tabBarActiveBackgroundColor: `${colors.primary}16`,
          tabBarHideOnKeyboard: true,
      }}
    >
      <Tabs.Screen name="index" options={{ title: "Home", tabBarAccessibilityLabel: "Home dashboard", tabBarIcon: ({ color }) => <IconSymbol name="house.fill" size={22} color={color} /> }} />
      <Tabs.Screen name="inspect" options={{ title: "Inspect", tabBarAccessibilityLabel: "Inspect evidence", tabBarIcon: ({ color }) => <IconSymbol name="camera.fill" size={22} color={color} /> }} />
      <Tabs.Screen name="explore" options={{ title: "Explore", tabBarAccessibilityLabel: "Explore initiatives", tabBarIcon: ({ color }) => <IconSymbol name="square.grid.2x2.fill" size={22} color={color} /> }} />
      <Tabs.Screen name="governance" options={{ title: "Governance", tabBarAccessibilityLabel: "Governance proposals", tabBarIcon: ({ color }) => <IconSymbol name="checkmark.seal.fill" size={22} color={color} /> }} />
      <Tabs.Screen name="profile" options={{ title: "Profile", tabBarAccessibilityLabel: "Profile and settings", tabBarIcon: ({ color }) => <IconSymbol name="person.crop.circle.fill" size={22} color={color} /> }} />
    </Tabs>
  );
}
