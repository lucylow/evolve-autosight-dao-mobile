import { Stack, useLocalSearchParams, useRouter } from "expo-router";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { initiatives } from "@/lib/evolve-data";
import { useColors } from "@/hooks/use-colors";

export default function InitiativeDetailScreen() {
  const colors = useColors();
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const item = initiatives.find((initiative) => initiative.id === id) ?? initiatives[0];
  const accent = item.accent === "violet" ? "#9B8AFB" : item.accent === "green" ? colors.success : colors.primary;

  return (
    <ScreenContainer edges={["top", "left", "right", "bottom"]} className="px-5 pt-3">
      <Stack.Screen options={{ headerShown: false }} />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <Pressable onPress={() => router.back()} style={({ pressed }) => [styles.back, pressed && { opacity: 0.6 }]}><IconSymbol name="chevron.right" size={22} color={colors.foreground} style={styles.backIcon} /><Text style={[styles.backText, { color: colors.foreground }]}>Back</Text></Pressable>
        <View style={[styles.iconBox, { backgroundColor: `${accent}1A` }]}><IconSymbol name={item.category === "Verification" ? "shield.fill" : item.category === "Governance" ? "checkmark.seal.fill" : "sparkles"} size={28} color={accent} /></View>
        <Text style={[styles.category, { color: accent }]}>{item.category.toUpperCase()}</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>{item.title}</Text>
        <Text style={[styles.summary, { color: colors.muted }]}>{item.summary}</Text>
        <View style={styles.chips}><View style={[styles.chip, { backgroundColor: `${accent}18` }]}><Text style={[styles.chipText, { color: accent }]}>{item.status}</Text></View><View style={[styles.chip, { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 }]}><Text style={[styles.chipText, { color: colors.muted }]}>AutoSight tracked</Text></View></View>
        <View style={[styles.statsCard, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardLabel, { color: colors.muted }]}>CURRENT SIGNAL</Text><View style={styles.statRow}><Text style={[styles.statValue, { color: colors.foreground }]}>{item.metric}</Text><Text style={[styles.statLabel, { color: colors.muted }]}>{item.metricLabel}</Text></View><View style={[styles.progressTrack, { backgroundColor: colors.border }]}><View style={[styles.progressFill, { backgroundColor: accent, width: item.category === "Governance" ? "72%" : "84%" }]} /></View></View>
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Why it matters</Text>
        <Text style={[styles.body, { color: colors.muted }]}>Evolve Insight connects operational evidence with a shared trust layer. This initiative is designed to make quality signals easier to understand, verify, and act on across organizations.</Text>
        <View style={[styles.timeline, { borderColor: colors.border }]}><TimelineStep label="Evidence collected" active colors={colors} /><TimelineStep label="Signal analyzed" active colors={colors} /><TimelineStep label="Community action" colors={colors} /></View>
        <Pressable onPress={() => router.push("/explore")} style={({ pressed }) => [styles.primaryButton, { backgroundColor: colors.primary }, pressed && { opacity: 0.8 }]}><Text style={[styles.primaryText, { color: colors.background }]}>Review related signals</Text><IconSymbol name="arrow.up.right" size={18} color={colors.background} /></Pressable>
      </ScrollView>
    </ScreenContainer>
  );
}

function TimelineStep({ label, active, colors }: { label: string; active?: boolean; colors: ReturnType<typeof useColors> }) {
  return <View style={styles.timelineStep}><View style={[styles.timelineDot, { backgroundColor: active ? colors.primary : colors.border }]} /> <Text style={[styles.timelineLabel, { color: active ? colors.foreground : colors.muted }]}>{label}</Text></View>;
}

const styles = StyleSheet.create({
  content: { paddingBottom: 30 },
  back: { flexDirection: "row", alignItems: "center", marginBottom: 30 },
  backIcon: { transform: [{ rotate: "180deg" }] },
  backText: { fontSize: 14, fontWeight: "700", marginLeft: 2 },
  iconBox: { width: 62, height: 62, borderRadius: 20, alignItems: "center", justifyContent: "center", marginBottom: 18 },
  category: { fontSize: 11, letterSpacing: 1.5, fontWeight: "800", marginBottom: 9 },
  title: { fontSize: 32, lineHeight: 38, fontWeight: "800", letterSpacing: -0.8, marginBottom: 11 },
  summary: { fontSize: 16, lineHeight: 24, marginBottom: 16 },
  chips: { flexDirection: "row", gap: 8, marginBottom: 25 },
  chip: { borderRadius: 999, paddingHorizontal: 11, paddingVertical: 7 },
  chipText: { fontSize: 11, fontWeight: "800" },
  statsCard: { borderWidth: 1, borderRadius: 20, padding: 17, marginBottom: 27 },
  cardLabel: { fontSize: 10, letterSpacing: 1.2, fontWeight: "800", marginBottom: 11 },
  statRow: { flexDirection: "row", alignItems: "baseline", gap: 8, marginBottom: 14 },
  statValue: { fontSize: 28, fontWeight: "800" },
  statLabel: { fontSize: 13 },
  progressTrack: { height: 7, borderRadius: 99, overflow: "hidden" },
  progressFill: { height: 7, borderRadius: 99 },
  sectionTitle: { fontSize: 18, fontWeight: "800", marginBottom: 9 },
  body: { fontSize: 14, lineHeight: 22, marginBottom: 23 },
  timeline: { borderLeftWidth: 1, paddingLeft: 18, marginLeft: 5, marginBottom: 28, gap: 17 },
  timelineStep: { flexDirection: "row", alignItems: "center", marginLeft: -24 },
  timelineDot: { width: 11, height: 11, borderRadius: 6, marginRight: 13 },
  timelineLabel: { fontSize: 14, fontWeight: "700" },
  primaryButton: { minHeight: 50, borderRadius: 15, paddingHorizontal: 17, alignItems: "center", justifyContent: "space-between", flexDirection: "row" },
  primaryText: { fontSize: 14, fontWeight: "800" },
});
