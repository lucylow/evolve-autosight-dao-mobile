import { CameraView, useCameraPermissions, type BarcodeScanningResult } from "expo-camera";
import * as Network from "expo-network";
import * as DocumentPicker from "expo-document-picker";
import * as Haptics from "expo-haptics";
import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";
import { Stack, useRouter } from "expo-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { Alert, Modal, Platform, Pressable, ScrollView, Share, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { OPERATOR_ACTIVITY_KEY, SCAN_HISTORY_KEY, SCAN_LAST_SYNC_KEY, inspections, type OperatorActivity } from "@/lib/evolve-data";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";
import { validateAuditFileText, type AuditExportEnvelope, type AuditValidationResult } from "@/lib/audit-file";
import { formatNextAttempt, formatRetryCountdown, getNextAttemptAt, isRetryDue } from "@/lib/retry-schedule";
import { filterOperatorActivity, getFailureCategory, serializeOperatorActivity, validateOperatorActivityText, type ActivityDateRange, type ActivityFilter } from "@/lib/operator-activity";
import { safeRead, safeRemove, safeWrite } from "@/lib/safe-storage";
import { getUpgradeMessage, isFeatureEntitled, type MonetizationPlan } from "@/lib/monetization";
import { clampCameraZoom, classifyScanPayload, formatScanSessionSummary, getCaptureReadiness, getFramingState, getScanConfidenceLabel, MAX_CAMERA_ZOOM, MIN_CAMERA_ZOOM } from "@/lib/vision";

type RetryEvent = { time: string; outcome: "synced" | "failed" | "queued"; network: string; detail: string; ackId: string };
type ScanAttempt = { label: string; status: "found" | "not-found"; time: string; createdAt?: string; syncStatus: "pending" | "synced" | "local-only"; retryCount: number; lastAttempt: string; nextAttemptAt?: string; errorMessage?: string; retryEvents: RetryEvent[] };
type AuditDateRange = "all" | "today" | "7d" | "30d";
const auditRangeLabels: Record<AuditDateRange, string> = { all: "All dates", today: "Today", "7d": "7 days", "30d": "30 days" };
type QueueFilter = "all" | "pending" | "synced" | "local-only" | "due";
type EventFilter = "all" | RetryEvent["outcome"];
type AcknowledgementResult = { ackId?: string; backend: boolean };
type BatchRetryResult = { succeeded: number; failed: number; skipped: number };
const CURRENT_MONETIZATION_PLAN: MonetizationPlan = "community";
const canExportAudits = isFeatureEntitled(CURRENT_MONETIZATION_PLAN, "auditExports");

function createAckId(label: string, time: string, outcome: RetryEvent["outcome"]) {
  return `ack-${outcome}-${label.replace(/[^a-zA-Z0-9]/g, "").slice(0, 16).toLowerCase()}-${time.replace(/[^0-9]/g, "")}`;
}


function parseInspectionId(data: string) {
  const match = data.match(/(?:inspection|verify|c)\/?([A-Z]{2,5}-\d+)/i);
  return match?.[1]?.toUpperCase() ?? null;
}

export default function ScanScreen() {
  const colors = useColors();
  const router = useRouter();
  const { mutateAsync: acknowledgeAsync } = trpc.audit.acknowledge.useMutation();
  const [permission, requestPermission] = useCameraPermissions();
  const [scanned, setScanned] = useState(false);
  const [torchEnabled, setTorchEnabled] = useState(false);
  const [cameraZoom, setCameraZoom] = useState(MIN_CAMERA_ZOOM);
  const [scanQualityMessage, setScanQualityMessage] = useState("Improve lighting, avoid glare, and fill the frame with the QR code.");
  const [scanQuality, setScanQuality] = useState<"empty" | "malformed" | "verification">("empty");
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [cameraKey, setCameraKey] = useState(0);
  const [sessionStats, setSessionStats] = useState({ readable: 0, verified: 0, adjustments: 0 });
  const lastBarcodeRef = useRef<{ data: string; at: number } | null>(null);
  const [message, setMessage] = useState("Point your camera at an Evolve verification code.");
  const [storageWarning, setStorageWarning] = useState<string | null>(null);
  const [history, setHistory] = useState<ScanAttempt[]>([]);
  const [lastSynced, setLastSynced] = useState<string | null>(null);
  const [syncState, setSyncState] = useState<"idle" | "syncing" | "synced" | "failed">("idle");
  const [queueFilter, setQueueFilter] = useState<QueueFilter>("all");
  const network = Network.useNetworkState();
  const isOnline = network.isInternetReachable ?? network.isConnected ?? false;
  const previousOnline = useRef(isOnline);
  const networkLabel = String(network.type ?? "unknown").toLowerCase();
  const notifyScan = useCallback(async (kind: "success" | "warning" | "error") => {
    if (Platform.OS === "web") return;
    try { await Haptics.notificationAsync(kind === "success" ? Haptics.NotificationFeedbackType.Success : kind === "warning" ? Haptics.NotificationFeedbackType.Warning : Haptics.NotificationFeedbackType.Error); } catch { /* Haptics are optional and must never block the audit workflow. */ }
  }, []);
  const requestAcknowledgement = useCallback(async (input: { record: string; outcome: "synced" | "failed"; eventTime: string; network: string }): Promise<AcknowledgementResult> => {
    try {
      return { ackId: (await acknowledgeAsync(input)).ackId, backend: true };
    } catch {
      return { backend: false };
    }
  }, [acknowledgeAsync]);
  useEffect(() => {
    void (async () => {
      const storedHistory = await safeRead(SCAN_HISTORY_KEY);
      if (storedHistory.error) setStorageWarning("Local scan history could not be read; new scans will remain in memory until storage recovers.");
      if (storedHistory.value) {
        try { const parsed = JSON.parse(storedHistory.value) as Partial<ScanAttempt>[]; setHistory(parsed.map<ScanAttempt>((item) => ({ label: item.label ?? "Unknown", status: (item.status === "found" ? "found" : "not-found"), time: item.time ?? "—", syncStatus: (item.syncStatus ?? (item.status === "found" ? "pending" : "local-only")) as ScanAttempt["syncStatus"], retryCount: item.retryCount ?? 0, lastAttempt: item.lastAttempt ?? item.time ?? "—", nextAttemptAt: item.nextAttemptAt, createdAt: item.createdAt, errorMessage: item.errorMessage, retryEvents: Array.isArray(item.retryEvents) ? (item.retryEvents as Partial<RetryEvent>[]).map((event) => ({ time: event.time ?? "—", outcome: event.outcome ?? "queued", network: event.network ?? "unknown", detail: event.detail ?? "No detail", ackId: event.ackId ?? createAckId(item.label ?? "unknown", event.time ?? "—", event.outcome ?? "queued") })) : [] }))); } catch { setHistory([]); setStorageWarning("Stored scan history was invalid and was safely ignored."); }
      }
      const storedLastSync = await safeRead(SCAN_LAST_SYNC_KEY);
      if (storedLastSync.error) setStorageWarning("Sync metadata could not be read; scan history remains available locally.");
      if (storedLastSync.value) setLastSynced(storedLastSync.value);
    })();
  }, []);
  const persistHistory = async (next: ScanAttempt[]) => { setHistory(next); const result = await safeWrite(SCAN_HISTORY_KEY, JSON.stringify(next)); if (!result.ok) setStorageWarning("Local storage is unavailable; this change remains in memory until storage recovers."); };
  const clearHistory = () => Alert.alert("Clear scan history?", "This removes locally stored scan attempts from this device.", [{ text: "Cancel", style: "cancel" }, { text: "Clear history", style: "destructive", onPress: async () => { setHistory([]); setLastSynced(null); setSyncState("idle"); const result = await safeRemove([SCAN_HISTORY_KEY, SCAN_LAST_SYNC_KEY]); if (!result.ok) setStorageWarning("Scan history was cleared in memory, but device storage could not be updated."); } }]);
  const retrySync = useCallback(async (): Promise<BatchRetryResult> => {
    if (!isOnline) { setSyncState("failed"); void notifyScan("warning"); return { succeeded: 0, failed: 0, skipped: history.length }; }
    setSyncState("syncing");
    await new Promise((resolve) => setTimeout(resolve, 650));
    const stamp = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    let succeeded = 0;
    let failed = 0;
    let skipped = 0;
    const syncedHistory = await Promise.all(history.map(async (item) => {
      if (item.status !== "found" || !isRetryDue(item.nextAttemptAt)) { skipped += 1; return item; }
      const acknowledgement = await requestAcknowledgement({ record: item.label, outcome: "synced", eventTime: stamp, network: networkLabel });
      const backendAccepted = acknowledgement.backend;
      if (backendAccepted) succeeded += 1; else failed += 1;
      const retryCount = backendAccepted ? item.retryCount : item.retryCount + 1;
      return { ...item, syncStatus: backendAccepted ? "synced" as const : "pending" as const, retryCount, nextAttemptAt: backendAccepted ? undefined : getNextAttemptAt(new Date(), retryCount), lastAttempt: stamp, errorMessage: backendAccepted ? undefined : "Backend acknowledgement unavailable · retry when online", retryEvents: [...item.retryEvents, { time: stamp, outcome: backendAccepted ? "synced" as const : "failed" as const, network: networkLabel, detail: backendAccepted ? "Verification record acknowledged by backend" : "Backend acknowledgement failed; local fallback recorded", ackId: acknowledgement.ackId ?? createAckId(item.label, stamp, backendAccepted ? "synced" : "failed") }] };
    }));
    setHistory(syncedHistory);
    const historyWrite = await safeWrite(SCAN_HISTORY_KEY, JSON.stringify(syncedHistory));
    if (!historyWrite.ok) setStorageWarning("Sync completed in memory, but the updated queue could not be persisted.");
    setLastSynced(stamp);
    const hasBackendFailures = syncedHistory.some((item) => item.syncStatus === "pending" && item.errorMessage?.includes("Backend acknowledgement"));
    setSyncState(hasBackendFailures ? "failed" : "synced");
    void notifyScan(hasBackendFailures ? "warning" : "success");
    const syncWrite = await safeWrite(SCAN_LAST_SYNC_KEY, stamp);
    if (!syncWrite.ok) setStorageWarning("Sync completed, but the last-sync time could not be persisted.");
    return { succeeded, failed, skipped };
  }, [history, isOnline, networkLabel, notifyScan, requestAcknowledgement]);
  const retrySyncSafely = useCallback(async (): Promise<BatchRetryResult> => {
    try { return await retrySync(); } catch { setSyncState("failed"); setStorageWarning("Sync encountered an unexpected error; your local audit queue was preserved."); void notifyScan("error"); return { succeeded: 0, failed: history.length, skipped: 0 }; }
  }, [history.length, notifyScan, retrySync]);
  useEffect(() => { if (isOnline && !previousOnline.current && history.length > 0) void retrySyncSafely(); previousOnline.current = isOnline; }, [history.length, isOnline, retrySyncSafely]);
  const retryRecord = async (label: string, force = false, overrideReason = "Operator override: retry now") => {
    const scheduledItem = history.find((item) => item.label === label);
    if (!force && scheduledItem?.nextAttemptAt && !isRetryDue(scheduledItem.nextAttemptAt)) {
      setSyncState("failed");
      return;
    }
    const now = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    if (!isOnline) {
      setSyncState("failed");
      await persistHistory(history.map((item) => item.label === label ? { ...item, retryCount: item.retryCount + 1, nextAttemptAt: getNextAttemptAt(new Date(), item.retryCount + 1), lastAttempt: now, errorMessage: "No connection · retry when online", retryEvents: [...item.retryEvents, { time: now, outcome: "failed" as const, network: networkLabel, detail: force ? `${overrideReason} · retry blocked while offline` : "Retry blocked while offline", ackId: createAckId(label, now, "failed") }] } : item));
      return;
    }
    setSyncState("syncing");
    await new Promise((resolve) => setTimeout(resolve, 450));
    const acknowledgement = await requestAcknowledgement({ record: label, outcome: "synced", eventTime: now, network: networkLabel });
    await persistHistory(history.map((item) => item.label === label && item.status === "found" ? { ...item, syncStatus: acknowledgement.backend ? "synced" as const : "pending" as const, retryCount: item.retryCount + 1, nextAttemptAt: acknowledgement.backend ? undefined : getNextAttemptAt(new Date(), item.retryCount + 1), lastAttempt: now, errorMessage: acknowledgement.backend ? undefined : "Backend acknowledgement unavailable · retry when online", retryEvents: [...item.retryEvents, { time: now, outcome: acknowledgement.backend ? "synced" as const : "failed" as const, network: networkLabel, detail: acknowledgement.backend ? (force ? `${overrideReason} · individual verification retry acknowledged by backend` : "Individual verification retry acknowledged by backend") : (force ? `${overrideReason} · backend acknowledgement failed; local fallback recorded` : "Backend acknowledgement failed; local fallback recorded"), ackId: acknowledgement.ackId ?? createAckId(label, now, acknowledgement.backend ? "synced" : "failed") }] } : item));
    setSyncState(acknowledgement.backend ? "synced" : "failed");
    if (!acknowledgement.backend) void notifyScan("warning");
  };
  const openHistoryRecord = (label: string) => { const record = inspections.find((item) => item.partNumber === label || item.id === label); if (record) router.replace((`/verification/${record.id}`) as any); };
  const visibleHistory = history.filter((item) => queueFilter === "all" || (queueFilter === "due" ? item.syncStatus === "pending" && isRetryDue(item.nextAttemptAt) : item.syncStatus === queueFilter));
  const saveAttempt = async (label: string, status: "found" | "not-found") => {
    const now = new Date();
    const duplicate = history.find((item) => item.label === label && item.createdAt && now.getTime() - new Date(item.createdAt).getTime() < 2200);
    if (duplicate) return;
    const next: ScanAttempt[] = [{ label, status, createdAt: now.toISOString(), syncStatus: (status === "found" ? "pending" : "local-only") as ScanAttempt["syncStatus"], retryCount: 0, lastAttempt: now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }), time: now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }), retryEvents: [{ time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }), outcome: "queued" as const, network: networkLabel, detail: status === "found" ? "Verification record queued for sync" : "Unresolved scan stored locally", ackId: "pending" }] }, ...history].slice(0, 4);
    setHistory(next);
    const historyWrite = await safeWrite(SCAN_HISTORY_KEY, JSON.stringify(next));
    if (!historyWrite.ok) setStorageWarning("The scan was recorded in memory, but local persistence is unavailable.");
  };

  const adjustZoom = (delta: number) => setCameraZoom((value) => { const next = clampCameraZoom(value + delta); if (next !== value) setSessionStats((stats) => ({ ...stats, adjustments: stats.adjustments + 1 })); return next; });
  const resetScanner = () => { setScanned(false); setMessage("Point your camera at an Evolve verification code."); setScanQuality("empty"); setScanQualityMessage("Improve lighting, avoid glare, and fill the frame with the QR code."); setTorchEnabled(false); setCameraZoom(MIN_CAMERA_ZOOM); setCameraError(null); setSessionStats({ readable: 0, verified: 0, adjustments: 0 }); setCameraKey((value) => value + 1); };

  const handleBarcode = ({ data }: BarcodeScanningResult) => {
    const quality = classifyScanPayload(data);
    setScanQuality(quality.quality);
    setScanQualityMessage(getCaptureReadiness(torchEnabled, quality.quality, cameraZoom).message);
    if (quality.quality === "empty") { setMessage(quality.message); return; }
    const now = Date.now();
    if (scanned || (lastBarcodeRef.current?.data === data && now - lastBarcodeRef.current.at < 2200)) return;
    lastBarcodeRef.current = { data, at: now };
    setSessionStats((stats) => ({ readable: stats.readable + 1, verified: quality.quality === "verification" ? stats.verified + 1 : stats.verified, adjustments: stats.adjustments }));
    setScanned(true);
    const id = parseInspectionId(data);
    if (!id) {
      setMessage(quality.message);
      void saveAttempt(data.slice(0, 18), "not-found");
      void notifyScan("warning");
      setMessage("This code is not an Evolve verification record. Try another code.");
      setTimeout(() => setScanned(false), 1200);
      return;
    }
    const record = inspections.find((item) => item.id === id || item.partNumber === id);
    if (!record) {
      setMessage(`Code ${id} was readable but no matching local evidence record was found.`);
      void saveAttempt(id, "not-found");
      void notifyScan("error");
      setMessage(`No local record found for ${id}. A live lookup will be added with backend sync.`);
      setTimeout(() => setScanned(false), 1600);
      return;
    }
    void saveAttempt(record.partNumber, "found");
    void notifyScan("success");
    router.replace((`/verification/${record.id}`) as any);
  };

  if (Platform.OS === "web") {
    return <FallbackScreen colors={colors} storageWarning={storageWarning} onBack={() => router.back()} onSelect={openHistoryRecord} onClear={clearHistory} onRetrySync={retrySyncSafely} syncState={syncState} lastSynced={lastSynced} isOnline={isOnline} networkLabel={networkLabel} filter={queueFilter} onFilterChange={setQueueFilter} onRetryRecord={retryRecord} onRetryDue={retrySyncSafely} history={visibleHistory} totalCount={history.length} message="Camera scanning requires a native development or production build. Use the shared verification link in the meantime." />;
  }
  if (!permission) return <ScreenContainer edges={["top", "bottom", "left", "right"]} className="items-center justify-center"><Text style={{ color: colors.muted }}>Preparing camera…</Text></ScreenContainer>;
  if (!permission.granted) return <FallbackScreen colors={colors} storageWarning={storageWarning} onBack={() => router.back()} onSelect={openHistoryRecord} onClear={clearHistory} onRetrySync={retrySyncSafely} syncState={syncState} lastSynced={lastSynced} isOnline={isOnline} networkLabel={networkLabel} filter={queueFilter} onFilterChange={setQueueFilter} onRetryRecord={retryRecord} onRetryDue={retrySyncSafely} history={visibleHistory} totalCount={history.length} message="Camera access is needed to scan component verification codes." onPrimary={requestPermission} primaryLabel="Allow camera access" />;

  return <ScreenContainer edges={["top", "bottom", "left", "right"]} containerClassName="bg-background"><Stack.Screen options={{ headerShown: false }} /><View style={styles.container}><CameraView key={cameraKey} style={styles.camera} facing="back" zoom={cameraZoom} enableTorch={torchEnabled} barcodeScannerSettings={{ barcodeTypes: ["qr"] }} onCameraReady={() => setCameraError(null)} onMountError={() => { setCameraError("Camera preview could not start. Check camera permissions or reopen the scanner."); void notifyScan("error"); }} onBarcodeScanned={scanned ? undefined : handleBarcode}><View style={styles.overlay}><View style={styles.cameraActions}><Pressable accessibilityRole="button" accessibilityLabel="Close scanner" onPress={() => router.back()} style={styles.close}><IconSymbol name="chevron.right" size={22} color="#FFFFFF" style={styles.closeIcon} /><Text style={styles.closeText}>Close</Text></Pressable><View style={styles.controlGroup}><Pressable accessibilityRole="button" accessibilityLabel="Decrease camera zoom" onPress={() => adjustZoom(-0.1)} disabled={cameraZoom <= MIN_CAMERA_ZOOM} style={[styles.torchButton, cameraZoom <= MIN_CAMERA_ZOOM && styles.disabledControl]}><Text style={styles.torchText}>−</Text></Pressable><Text style={styles.zoomText}>{Math.round(cameraZoom * 100)}%</Text><Pressable accessibilityRole="button" accessibilityLabel="Increase camera zoom" onPress={() => adjustZoom(0.1)} disabled={cameraZoom >= MAX_CAMERA_ZOOM} style={[styles.torchButton, cameraZoom >= MAX_CAMERA_ZOOM && styles.disabledControl]}><Text style={styles.torchText}>＋</Text></Pressable><Pressable accessibilityRole="button" accessibilityLabel={torchEnabled ? "Turn flashlight off" : "Turn flashlight on"} onPress={() => setTorchEnabled((value) => !value)} style={styles.torchButton}><Text style={styles.torchText}>{torchEnabled ? "Light off" : "Use light"}</Text></Pressable></View></View><View style={[styles.scanArea, { borderColor: scanQuality === "verification" ? "#22C55E" : colors.primary }]}><View style={[styles.corner, styles.topLeft, { borderColor: scanQuality === "verification" ? "#22C55E" : colors.primary }]} /><View style={[styles.corner, styles.topRight, { borderColor: scanQuality === "verification" ? "#22C55E" : colors.primary }]} /><View style={[styles.corner, styles.bottomLeft, { borderColor: scanQuality === "verification" ? "#22C55E" : colors.primary }]} /><View style={[styles.corner, styles.bottomRight, { borderColor: scanQuality === "verification" ? "#22C55E" : colors.primary }]} /><Text style={[styles.framingBadge, { color: scanQuality === "verification" ? "#BBF7D0" : "#FFFFFF" }]}>{getFramingState(scanQuality, cameraZoom).label}</Text></View><View style={styles.bottomPanel}>{cameraError && <><Text style={styles.cameraError}>{cameraError}</Text><Pressable accessibilityRole="button" accessibilityLabel="Retry camera preview" onPress={resetScanner} style={[styles.retry, { backgroundColor: colors.primary }]}><Text style={[styles.retryText, { color: colors.background }]}>Retry camera</Text></Pressable></>}<Text style={styles.scanTitle}>Verify a component</Text><Text style={styles.scanMessage}>{message}</Text><Text style={styles.scanGuidance}>{getScanConfidenceLabel(scanQuality)} · {scanQualityMessage}</Text><Text style={styles.syncMessage}>{formatScanSessionSummary(sessionStats)}</Text><Text style={styles.syncMessage}>{isOnline ? `Online via ${networkLabel} · sync is available` : "Offline-ready · scans are saved locally until sync is available"}</Text>{scanned && <Pressable onPress={resetScanner} style={[styles.retry, { backgroundColor: colors.primary }]}><Text style={[styles.retryText, { color: colors.background }]}>Scan again</Text></Pressable>}</View></View></CameraView></View></ScreenContainer>;
}

function FallbackScreen({ colors, storageWarning, message, onBack, onPrimary, primaryLabel, history, totalCount, filter, onFilterChange, onRetryRecord, onRetryDue, onSelect, onClear, onRetrySync, syncState, lastSynced, isOnline, networkLabel }: { colors: ReturnType<typeof useColors>; storageWarning: string | null; message: string; onBack: () => void; onPrimary?: () => void; primaryLabel?: string; history: ScanAttempt[]; totalCount: number; filter: QueueFilter; onFilterChange: (filter: QueueFilter) => void; onRetryRecord: (label: string, force?: boolean) => void; onRetryDue: () => Promise<BatchRetryResult>; onSelect: (label: string) => void; onClear: () => void; onRetrySync: () => void; syncState: "idle" | "syncing" | "synced" | "failed"; lastSynced: string | null; isOnline: boolean; networkLabel: string }) {
  const [auditOpen, setAuditOpen] = useState(false);
  const [selectedAudit, setSelectedAudit] = useState<ScanAttempt | null>(null);
  const [eventFilter, setEventFilter] = useState<EventFilter>("all");
  const [retryConfirmOpen, setRetryConfirmOpen] = useState(false);
  const [importPreview, setImportPreview] = useState<{ fileName: string; validation: AuditValidationResult } | null>(null);
  const [auditRange, setAuditRange] = useState<AuditDateRange>("all");
  const [clock, setClock] = useState(() => Date.now());
  useEffect(() => {
    if (!history.some((item) => item.nextAttemptAt)) return;
    const timer = setInterval(() => setClock(Date.now()), 1000);
    return () => clearInterval(timer);
  }, [history]);
  const [activity, setActivity] = useState<OperatorActivity[]>([]);
  const [activityFilter, setActivityFilter] = useState<ActivityFilter>("all");
  const [activityRange, setActivityRange] = useState<ActivityDateRange>("all");
  const [failureAction, setFailureAction] = useState<{ title: string; run: () => Promise<unknown> } | null>(null);
  const [activityWarning, setActivityWarning] = useState<string | null>(null);
  useEffect(() => {
    void (async () => {
      const stored = await safeRead(OPERATOR_ACTIVITY_KEY);
      if (stored.error) setActivityWarning("Operator activity could not be read; new activity remains available in memory.");
      if (!stored.value) return;
      try { setActivity(JSON.parse(stored.value) as OperatorActivity[]); } catch { setActivity([]); setActivityWarning("Stored operator activity was invalid and was safely ignored."); }
    })();
  }, []);
  const visibleActivity = filterOperatorActivity(activity, activityFilter, activityRange);
  const exportActivity = async (format: "json" | "csv") => {
    if (!canExportAudits) { Alert.alert("Audit exports are an organization feature", getUpgradeMessage("auditExports")); return; }
    const body = serializeOperatorActivity(visibleActivity, format);
    const fileName = `evolve-operator-activity-${activityRange}.${format}`;
    if (Platform.OS === "web") { await Share.share({ title: fileName, message: body }); return; }
    const base = FileSystem.cacheDirectory;
    if (!base) { await Share.share({ title: fileName, message: body }); return; }
    const uri = `${base}${fileName}`;
    await FileSystem.writeAsStringAsync(uri, body, { encoding: FileSystem.EncodingType.UTF8 });
    if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(uri, { dialogTitle: `Share ${fileName}`, mimeType: format === "json" ? "application/json" : "text/csv" });
    else await Share.share({ title: fileName, message: body });
  };
  const appendActivity = async (entry: OperatorActivity) => {
    const next = [entry, ...activity].slice(0, 20);
    setActivity(next);
    const result = await safeWrite(OPERATOR_ACTIVITY_KEY, JSON.stringify(next));
    if (!result.ok) setActivityWarning("Operator activity was updated in memory, but could not be saved to device storage.");
  };
  const runDueRetry = async () => {
    const result = await onRetryDue();
    const time = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    await appendActivity({ id: `batch-retry-${Date.now()}`, time, kind: "batch-retry", summary: `Retried ${result.succeeded + result.failed} due records`, detail: `${result.succeeded} succeeded · ${result.failed} failed · ${result.skipped} skipped` });
    Alert.alert("Batch retry complete", `${result.succeeded} succeeded · ${result.failed} failed · ${result.skipped} skipped.`);
  };
  const importActivityFile = async () => {
    const result = await DocumentPicker.getDocumentAsync({ type: ["application/json", "text/csv", "text/comma-separated-values"], copyToCacheDirectory: true });
    if (result.canceled) return;
    const asset = result.assets[0];
    const text = Platform.OS === "web" && asset.file ? await asset.file.text() : await FileSystem.readAsStringAsync(asset.uri, { encoding: FileSystem.EncodingType.UTF8 });
    const format = asset.name.toLowerCase().endsWith(".csv") ? "csv" : "json";
    const validation = validateOperatorActivityText(text, format);
    if (!validation.valid) { Alert.alert("Activity file rejected", `${asset.name}\n\n${validation.message}`); return; }
    Alert.alert("Activity file validated", `${asset.name}\n\n${validation.message}`);
  };
  const acceptImport = async () => {
    const fileName = importPreview?.fileName ?? "Audit file";
    setImportPreview(null);
    const time = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    await appendActivity({ id: `audit-import-${Date.now()}`, time, kind: "audit-import", summary: `Validated ${fileName}`, detail: importPreview?.validation.message ?? "Audit file passed integrity validation" });
    Alert.alert("Audit file accepted", `${fileName} passed validation and is ready for downstream processing.`);
  };
  const isWithinAuditRange = (item: ScanAttempt) => {
    if (auditRange === "all") return true;
    const createdAt = item.createdAt ? new Date(item.createdAt).getTime() : Date.now();
    const days = auditRange === "today" ? 1 : auditRange === "7d" ? 7 : 30;
    return Date.now() - createdAt <= days * 24 * 60 * 60 * 1000;
  };
  const dateFilteredHistory = history.filter(isWithinAuditRange);
  const backendPendingCount = history.filter((item) => item.syncStatus === "pending" && item.errorMessage?.includes("Backend acknowledgement")).length;
  const failureCategories = history.filter((item) => item.syncStatus === "pending" && item.errorMessage).reduce<Record<string, number>>((counts, item) => { const category = getFailureCategory(item.errorMessage); counts[category] = (counts[category] ?? 0) + 1; return counts; }, {});
  const failureSummary = Object.entries(failureCategories).map(([category, count]) => `${category}: ${count}`).join(" · ");
  const dueCount = history.filter((item) => item.status === "found" && item.syncStatus === "pending" && isRetryDue(item.nextAttemptAt)).length;
  const selectedEvents = selectedAudit?.retryEvents.filter((event) => eventFilter === "all" || event.outcome === eventFilter) ?? [];
  const failedEvents = selectedAudit?.retryEvents.filter((event) => event.outcome === "failed") ?? [];
  const failedEventLabels = failedEvents.map((event) => event.ackId).join(", ");
  const exportDiagnostics = async () => { if (!canExportAudits) { Alert.alert("Audit exports are an organization feature", getUpgradeMessage("auditExports")); return; } const summary = dateFilteredHistory.map((item) => `${item.label} | ${item.syncStatus} | retries ${item.retryCount} | last attempt ${item.lastAttempt}${item.errorMessage ? ` | ${item.errorMessage}` : ""}${item.retryEvents.length ? ` | ack ${item.retryEvents[item.retryEvents.length - 1].ackId}` : ""}`).join("\\n"); await Share.share({ title: "Evolve Insight queue diagnostics", message: `Evolve Insight queue diagnostics\\nDate range: ${auditRangeLabels[auditRange]}\\nTotal records: ${dateFilteredHistory.length}\\nNetwork: ${isOnline ? "online" : "offline"}\\n\\n${summary || "No scan records match this date range."}` }); };
  const exportSelectedAudit = async () => { if (!canExportAudits) { Alert.alert("Audit exports are an organization feature", getUpgradeMessage("auditExports")); return; } if (!selectedAudit) return; const events = selectedEvents.map((event) => `${event.time} | ${event.outcome} | ${event.network} | ${event.ackId} | ${event.detail}`).join("\\n"); await Share.share({ title: `Audit ${selectedAudit.label}`, message: `Evolve Insight record audit\\nRecord: ${selectedAudit.label}\\nState: ${selectedAudit.syncStatus}\\nDate range: ${auditRangeLabels[auditRange]}\\nFilter: ${eventFilter}\\n\\n${events || "No events match this filter."}` }); };
  const exportAuditFormat = async (format: "json" | "csv") => {
    if (!canExportAudits) { Alert.alert("Audit exports are an organization feature", getUpgradeMessage("auditExports")); return; }
    if (!selectedAudit) return;
    const exportFileName = `evolve-${selectedAudit.label.replace(/[^a-zA-Z0-9]/g, "-")}-audit-${auditRange}.${format}`;
    const records = selectedEvents.map((event) => ({ record: selectedAudit.label, state: selectedAudit.syncStatus, time: event.time, outcome: event.outcome, network: event.network, acknowledgementId: event.ackId, detail: event.detail, nextAttemptAt: selectedAudit.nextAttemptAt, retryCountdown: formatRetryCountdown(selectedAudit.nextAttemptAt, clock) }));
    const envelope: AuditExportEnvelope = { schemaVersion: 1, exportedAt: new Date().toISOString(), exportFileName, dateRange: auditRange, eventFilter, records, manifest: { activityIds: visibleActivity.map((entry) => entry.id), acknowledgementIds: selectedEvents.map((event) => event.ackId) } };
    const body = format === "json" ? JSON.stringify(envelope, null, 2) : ["# Evolve Insight Audit Export", `# schemaVersion=${envelope.schemaVersion}`, `# exportedAt=${envelope.exportedAt}`, `# exportFileName=${envelope.exportFileName}`, `# dateRange=${envelope.dateRange}`, `# eventFilter=${envelope.eventFilter}`, `# activityIds=${envelope.manifest?.activityIds.join("|") ?? ""}`, `# acknowledgementIds=${envelope.manifest?.acknowledgementIds.join("|") ?? ""}`, "record,state,time,outcome,network,acknowledgementId,detail,nextAttemptAt,retryCountdown", ...records.map((row) => [row.record, row.state, row.time, row.outcome, row.network, row.acknowledgementId, `"${row.detail.replaceAll('"', '""')}"`, row.nextAttemptAt ?? "", row.retryCountdown ?? ""].join(","))].join("\\n");
    if (Platform.OS === "web") { await Share.share({ title: exportFileName, message: body || `No ${eventFilter} events match this filter.` }); return; }
    const base = FileSystem.cacheDirectory;
    if (!base) { await Share.share({ title: exportFileName, message: body }); return; }
    const uri = `${base}${exportFileName}`;
    await FileSystem.writeAsStringAsync(uri, body, { encoding: FileSystem.EncodingType.UTF8 });
    if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(uri, { dialogTitle: `Share ${exportFileName}`, mimeType: format === "json" ? "application/json" : "text/csv" });
    else await Share.share({ title: exportFileName, message: body });
  };
  const importAuditFile = async () => {
    const result = await DocumentPicker.getDocumentAsync({ type: ["application/json", "text/csv", "text/comma-separated-values"], copyToCacheDirectory: true });
    if (result.canceled) return;
    const asset = result.assets[0];
    const text = Platform.OS === "web" && asset.file ? await asset.file.text() : await FileSystem.readAsStringAsync(asset.uri, { encoding: FileSystem.EncodingType.UTF8 });
    const format = asset.name.toLowerCase().endsWith(".csv") ? "csv" : "json";
    const validation = validateAuditFileText(text, format);
    if (!validation.valid) {
      Alert.alert("Audit file rejected", `${asset.name}\n\n${validation.message}`);
      return;
    }
    setImportPreview({ fileName: asset.name, validation });
    };
  const runSafely = (operation: () => Promise<unknown>, title: string) => { void operation().then(() => setFailureAction(null)).catch((error) => { setFailureAction({ title, run: operation }); Alert.alert(title, error instanceof Error ? error.message : "Please try again. Our local audit data was not deleted."); }); };
  return <ScreenContainer edges={["top", "bottom", "left", "right"]} className="px-5 pt-5"><View style={styles.fallback}><View style={[styles.fallbackIcon, { backgroundColor: `${colors.primary}18` }]}><IconSymbol name="camera.fill" size={28} color={colors.primary} /></View><Text style={[styles.fallbackTitle, { color: colors.foreground }]}>Scan verification</Text><Text style={[styles.fallbackMessage, { color: colors.muted }]}>{message}</Text>{(storageWarning || activityWarning || failureAction) && <View style={[styles.warningBanner, { borderColor: colors.warning, backgroundColor: `${colors.warning}14` }]}>{(storageWarning || activityWarning) && <Text style={[styles.warningBannerText, { color: colors.warning }]}>{storageWarning || activityWarning}</Text>}{failureAction && <Pressable accessibilityRole="button" accessibilityLabel={`Retry ${failureAction.title}`} onPress={() => runSafely(failureAction.run, failureAction.title)} style={[styles.recoveryRetry, { borderColor: colors.warning }]}><Text style={[styles.recoveryRetryText, { color: colors.warning }]}>Retry {failureAction.title}</Text></Pressable>}</View>}<View style={[styles.syncCard, { backgroundColor: colors.surface, borderColor: colors.border }]}><View style={styles.syncCopy}><Text style={[styles.syncTitle, { color: colors.foreground }]}>Local queue · {totalCount} scans · {isOnline ? "Online" : "Offline"} · {networkLabel}</Text><Text style={[styles.syncDetail, { color: colors.muted }]}>Pending {history.filter((item) => item.syncStatus === "pending").length} · Synced {history.filter((item) => item.syncStatus === "synced").length} · Local {history.filter((item) => item.syncStatus === "local-only").length}</Text><Text style={[styles.syncDetail, { color: colors.muted }]}>{syncState === "syncing" ? "Syncing with Evolve…" : syncState === "failed" ? (backendPendingCount > 0 ? `${backendPendingCount} record${backendPendingCount === 1 ? "" : "s"} still need backend acknowledgement` : "No connection · retry when online") : syncState === "synced" ? `Last synced at ${lastSynced}` : lastSynced ? `Last synced at ${lastSynced}` : "Not synced yet · safe to keep working offline"}</Text>{failureSummary && <Text style={[styles.syncDetail, { color: colors.error }]}>Failure categories · {failureSummary}</Text>}</View><Pressable accessibilityRole="button" accessibilityLabel="Sync pending scans" onPress={onRetrySync} disabled={syncState === "syncing" || !isOnline} style={({ pressed }) => [styles.syncAction, { borderColor: colors.border }, (pressed || syncState === "syncing") && { opacity: 0.55 }]}><Text style={[styles.syncActionText, { color: colors.primary }]}>{syncState === "syncing" ? "…" : isOnline ? "Sync" : "Offline"}</Text></Pressable></View>{onPrimary && <Pressable onPress={onPrimary} style={[styles.fallbackButton, { backgroundColor: colors.primary }]}><Text style={[styles.retryText, { color: colors.background }]}>{primaryLabel}</Text></Pressable>}{totalCount > 0 && <View style={[styles.historyCard, { backgroundColor: colors.surface, borderColor: colors.border }]}><View style={styles.historyHeader}><Text style={[styles.historyTitle, { color: colors.foreground }]}>Recent scans</Text><View style={styles.historyActions}><Pressable accessibilityRole="button" accessibilityLabel="Open queue audit" onPress={() => setAuditOpen(true)}><Text style={[styles.clearText, { color: colors.primary }]}>Audit</Text></Pressable><Pressable accessibilityRole="button" accessibilityLabel="Clear scan history" onPress={onClear}><Text style={[styles.clearText, { color: colors.primary }]}>Clear</Text></Pressable></View></View><View style={styles.filterRow}>{(["all", "pending", "synced", "local-only", "due"] as QueueFilter[]).map((option) => <Pressable accessibilityRole="button" accessibilityState={{ selected: filter === option }} accessibilityLabel={`Filter scans by ${option}`} key={option} onPress={() => onFilterChange(option)} style={({ pressed }) => [styles.filterChip, { borderColor: colors.border }, filter === option && { backgroundColor: `${colors.primary}16`, borderColor: colors.primary }, pressed && { transform: [{ scale: 0.97 }], opacity: 0.78 }]}><Text style={[styles.filterText, { color: filter === option ? colors.primary : colors.muted }]}>{option === "local-only" ? "Local" : option === "due" ? "Due" : option === "all" ? "All" : option[0].toUpperCase() + option.slice(1)}</Text></Pressable>)}</View>{history.length === 0 ? <Text style={[styles.emptyHistory, { color: colors.muted }]}>No scans in this filter.</Text> : history.map((item) => <Pressable accessibilityRole="button" accessibilityLabel={`${item.label} scan, ${item.syncStatus}`} key={`${item.label}-${item.time}`} onPress={() => item.status === "found" && onSelect(item.label)} style={({ pressed }) => [styles.historyRow, pressed && item.status === "found" && { transform: [{ scale: 0.985 }], opacity: 0.68 }]}><View style={[styles.historyDot, { backgroundColor: item.status === "found" ? colors.success : colors.warning }]} /><Text style={[styles.historyLabel, { color: colors.foreground }]} numberOfLines={1}>{item.label}</Text><Text style={[styles.historyTime, { color: colors.muted }]}>{item.time}</Text><Text style={[styles.historyAttempt, { color: colors.muted }]}>{item.retryCount > 0 ? `Retry ${item.retryCount}` : "New"}</Text><Text style={[styles.historyStatus, { color: item.syncStatus === "synced" ? colors.success : item.syncStatus === "pending" ? colors.primary : colors.muted }]}>{item.syncStatus === "synced" ? "Synced" : item.syncStatus === "pending" ? "Pending" : "Local only"}</Text>{item.errorMessage && <Text style={[styles.historyError, { color: colors.error }]} numberOfLines={1}>{item.errorMessage}</Text>}{item.nextAttemptAt && <Text style={[styles.historyError, { color: colors.primary }]} numberOfLines={1}>{formatRetryCountdown(item.nextAttemptAt, clock)} · {formatNextAttempt(item.nextAttemptAt)}</Text>}{item.syncStatus === "pending" && item.status === "found" && <Pressable accessibilityRole="button" accessibilityLabel={`${item.nextAttemptAt && !isRetryDue(item.nextAttemptAt) ? "Retry now" : "Retry sync"} for ${item.label}`} onPress={() => { if (item.nextAttemptAt && !isRetryDue(item.nextAttemptAt)) { Alert.alert("Retry before scheduled time?", `The next retry is scheduled for ${formatNextAttempt(item.nextAttemptAt)}. Override the schedule and retry now?`, [{ text: "Cancel", style: "cancel" }, { text: "Retry now", onPress: () => onRetryRecord(item.label, true) }]); } else onRetryRecord(item.label); }} disabled={!isOnline || syncState === "syncing"} style={[styles.rowRetry, { borderColor: colors.border }]}><Text style={[styles.rowRetryText, { color: isOnline ? colors.primary : colors.muted }]}>{item.nextAttemptAt && !isRetryDue(item.nextAttemptAt) ? "Retry now" : "Retry"}</Text></Pressable>}{item.status === "found" && <IconSymbol name="chevron.right" size={14} color={colors.muted} />}</Pressable>)}</View>}<Pressable onPress={onBack} style={[styles.secondaryButton, { borderColor: colors.border }]}><Text style={[styles.secondaryText, { color: colors.foreground }]}>Return to app</Text></Pressable></View><Modal visible={auditOpen} animationType="slide" transparent onRequestClose={() => setAuditOpen(false)}><View style={styles.modalBackdrop}><View style={[styles.auditSheet, { backgroundColor: colors.background }]}><View style={styles.auditHeader}><View><Text style={[styles.auditTitle, { color: colors.foreground }]}>Queue audit</Text><Text style={[styles.auditSubtitle, { color: colors.muted }]}>{totalCount} records · {isOnline ? "Online" : "Offline"}</Text></View><Pressable onPress={() => setAuditOpen(false)}><Text style={[styles.clearText, { color: colors.primary }]}>Done</Text></Pressable></View><View style={styles.eventFilterRow}>{(Object.keys(auditRangeLabels) as AuditDateRange[]).map((option) => <Pressable key={option} onPress={() => setAuditRange(option)} style={[styles.filterChip, { borderColor: colors.border }, auditRange === option && { backgroundColor: `${colors.primary}16`, borderColor: colors.primary }]}><Text style={[styles.filterText, { color: auditRange === option ? colors.primary : colors.muted }]}>{auditRangeLabels[option]}</Text></Pressable>)}</View><Text style={[styles.auditMeta, { color: colors.muted }]}>{dateFilteredHistory.length} records in {auditRangeLabels[auditRange].toLowerCase()}</Text>{activity.length > 0 && <View style={[styles.activityCard, { borderColor: colors.border }]}><Text style={[styles.auditLabel, { color: colors.foreground }]}>Operator activity</Text><View style={styles.eventFilterRow}>{(["all", "batch-retry", "audit-import"] as ActivityFilter[]).map((option) => <Pressable key={option} onPress={() => setActivityFilter(option)} style={[styles.filterChip, { borderColor: colors.border }, activityFilter === option && { backgroundColor: `${colors.primary}16`, borderColor: colors.primary }]}><Text style={[styles.filterText, { color: activityFilter === option ? colors.primary : colors.muted }]}>{option === "all" ? "All" : option === "batch-retry" ? "Retries" : "Imports"}</Text></Pressable>)}</View><View style={styles.eventFilterRow}>{(["all", "today", "7d", "30d"] as ActivityDateRange[]).map((option) => <Pressable key={option} onPress={() => setActivityRange(option)} style={[styles.filterChip, { borderColor: colors.border }, activityRange === option && { backgroundColor: `${colors.primary}16`, borderColor: colors.primary }]}><Text style={[styles.filterText, { color: activityRange === option ? colors.primary : colors.muted }]}>{option === "all" ? "All dates" : option === "today" ? "Today" : option}</Text></Pressable>)}</View>{visibleActivity.slice(0, 3).map((entry) => <Text key={entry.id} style={[styles.auditMeta, { color: colors.muted }]}>{entry.time} · {entry.summary} · {entry.detail}</Text>)}{visibleActivity.length === 0 && <Text style={[styles.auditMeta, { color: colors.muted }]}>No activity matches these filters.</Text>}<View style={styles.formatRow}><Pressable accessibilityRole="button" accessibilityLabel="Export operator activity as JSON" onPress={() => runSafely(() => exportActivity("json"), "Activity export failed")} style={[styles.formatButton, { borderColor: colors.border }]}><Text style={[styles.formatText, { color: colors.primary }]}>Activity JSON</Text></Pressable><Pressable accessibilityRole="button" accessibilityLabel="Export operator activity as CSV" onPress={() => runSafely(() => exportActivity("csv"), "Activity export failed")} style={[styles.formatButton, { borderColor: colors.border }]}><Text style={[styles.formatText, { color: colors.primary }]}>Activity CSV</Text></Pressable></View><Pressable accessibilityRole="button" accessibilityLabel="Import and validate operator activity" onPress={() => runSafely(importActivityFile, "Activity import failed")} style={[styles.detailButton, { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }]}><Text style={[styles.exportText, { color: colors.foreground }]}>Import activity</Text></Pressable></View>}<ScrollView contentContainerStyle={styles.auditList}>{dateFilteredHistory.length === 0 ? <Text style={[styles.emptyHistory, { color: colors.muted }]}>No records match this date range.</Text> : dateFilteredHistory.map((item) => <Pressable key={`audit-${item.label}-${item.time}`} accessibilityRole="button" accessibilityLabel={`Open audit for ${item.label}, ${item.syncStatus}, ${item.retryEvents.length} events`} onPress={() => setSelectedAudit(item)} style={[styles.auditRow, { borderBottomColor: colors.border }]}><Text style={[styles.auditLabel, { color: colors.foreground }]}>{item.label}</Text><Text style={[styles.auditMeta, { color: colors.muted }]}>{item.syncStatus} · {item.retryCount} retries · {item.retryEvents.length} events · last attempt {item.lastAttempt}{item.nextAttemptAt ? ` · next retry ${formatNextAttempt(item.nextAttemptAt)}` : ""}</Text>{item.errorMessage && <Text style={[styles.auditError, { color: colors.error }]}>{item.errorMessage}</Text>}</Pressable>)}</ScrollView>{dueCount > 0 && <Pressable accessibilityRole="button" accessibilityLabel={`Retry all ${dueCount} due records`} onPress={() => Alert.alert("Retry due records?", `${dueCount} record${dueCount === 1 ? "" : "s"} are eligible for retry now. This will request backend acknowledgements and append audit events.`, [{ text: "Cancel", style: "cancel" }, { text: "Retry due records", onPress: () => runSafely(runDueRetry, "Batch retry failed") }])} style={[styles.detailButton, { backgroundColor: colors.primary }]}><Text style={[styles.exportText, { color: colors.background }]}>Retry due records ({dueCount})</Text></Pressable>}<Pressable onPress={() => runSafely(importAuditFile, "Audit import failed")} style={[styles.detailButton, { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }]}><Text style={[styles.exportText, { color: colors.foreground }]}>Import and verify audit file</Text></Pressable><Pressable onPress={() => runSafely(exportDiagnostics, "Diagnostics export failed")} style={[styles.exportButton, { backgroundColor: colors.primary }]}><Text style={[styles.exportText, { color: colors.background }]}>Share diagnostics</Text></Pressable></View></View></Modal><Modal visible={importPreview !== null} animationType="fade" transparent onRequestClose={() => setImportPreview(null)}><View style={styles.modalBackdrop}><View style={[styles.confirmSheet, { backgroundColor: colors.background }]}><Text style={[styles.confirmTitle, { color: colors.foreground }]}>Review validated audit</Text><Text style={[styles.confirmCopy, { color: colors.muted }]}>{importPreview?.fileName}\n\n{importPreview?.validation.message}\n\nSchema: v{importPreview?.validation.envelope?.schemaVersion}\nDate range: {importPreview?.validation.envelope?.dateRange}\nEvent filter: {importPreview?.validation.envelope?.eventFilter}\n\nThe file passed structural integrity checks and is ready for external-system processing.</Text><Pressable accessibilityRole="button" accessibilityLabel="Acknowledge validated audit file" onPress={() => runSafely(acceptImport, "Audit acceptance failed")} style={[styles.detailButton, { backgroundColor: colors.primary }]}><Text style={[styles.exportText, { color: colors.background }]}>Accept validated file</Text></Pressable><Pressable accessibilityRole="button" accessibilityLabel="Cancel audit file import" onPress={() => setImportPreview(null)} style={[styles.detailButton, { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }]}><Text style={[styles.exportText, { color: colors.foreground }]}>Cancel</Text></Pressable></View></View></Modal><Modal visible={selectedAudit !== null} animationType="fade" transparent onRequestClose={() => setSelectedAudit(null)}><View style={styles.modalBackdrop}><View style={[styles.detailSheet, { backgroundColor: colors.background }]}>{selectedAudit && <><View style={styles.auditHeader}><View><Text style={[styles.auditTitle, { color: colors.foreground }]}>Record audit</Text><Text style={[styles.auditSubtitle, { color: colors.muted }]}>{selectedAudit.label}</Text></View><Pressable onPress={() => setSelectedAudit(null)}><Text style={[styles.clearText, { color: colors.primary }]}>Done</Text></Pressable></View><Text style={[styles.detailStatus, { color: selectedAudit.syncStatus === "synced" ? colors.success : selectedAudit.syncStatus === "pending" ? colors.primary : colors.muted }]}>{selectedAudit.syncStatus === "synced" ? "Synced to verification layer" : selectedAudit.syncStatus === "pending" ? "Pending network sync" : "Stored locally only"}</Text><Text style={[styles.auditMeta, { color: colors.muted }]}>Scan result: {selectedAudit.status} · {selectedAudit.retryCount} retries · last attempt {selectedAudit.lastAttempt}</Text><Text style={[styles.auditMeta, { color: colors.muted }]}>Audit summary: {selectedAudit.retryEvents.filter((event) => event.outcome === "failed").length} failed · {selectedAudit.retryEvents.filter((event) => event.outcome === "synced").length} synced · {selectedAudit.retryEvents.filter((event) => event.outcome === "queued").length} queued</Text><View style={styles.eventFilterRow}>{(["all", "queued", "failed", "synced"] as EventFilter[]).map((option) => <Pressable key={option} onPress={() => setEventFilter(option)} style={[styles.filterChip, { borderColor: colors.border }, eventFilter === option && { backgroundColor: `${colors.primary}16`, borderColor: colors.primary }]}><Text style={[styles.filterText, { color: eventFilter === option ? colors.primary : colors.muted }]}>{option[0].toUpperCase() + option.slice(1)}</Text></Pressable>)}</View><Text style={[styles.auditMeta, { color: colors.muted }]}>{selectedEvents.length} of {selectedAudit.retryEvents.length} events shown</Text><ScrollView style={styles.eventList} contentContainerStyle={styles.eventListContent}>{selectedEvents.length === 0 ? <Text style={[styles.auditMeta, { color: colors.muted }]}>{selectedAudit.retryEvents.length === 0 ? "No retry events recorded." : `No ${eventFilter} events in this record.`}</Text> : selectedEvents.map((event, index) => <View key={`${event.time}-${index}`} style={[styles.eventRow, { borderBottomColor: colors.border }]}><View style={[styles.eventDot, { backgroundColor: event.outcome === "synced" ? colors.success : event.outcome === "failed" ? colors.error : colors.primary }]} /><View style={styles.eventCopy}><Text style={[styles.auditLabel, { color: colors.foreground }]}>{event.outcome === "synced" ? "Synced" : event.outcome === "failed" ? "Failed" : "Queued"} · {event.network}</Text><Text style={[styles.auditMeta, { color: colors.muted }]}>{event.time} · {event.detail}</Text></View></View>)}</ScrollView>{selectedAudit.errorMessage && <Text style={[styles.auditError, { color: colors.error }]}>{selectedAudit.errorMessage}</Text>}<Pressable onPress={() => runSafely(exportSelectedAudit, "Audit export failed")} style={[styles.detailButton, { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }]}><Text style={[styles.exportText, { color: colors.foreground }]}>Share filtered audit</Text></Pressable><View style={styles.formatRow}><Pressable onPress={() => runSafely(() => exportAuditFormat("json"), "Audit export failed")} style={[styles.formatButton, { borderColor: colors.border }]}><Text style={[styles.formatText, { color: colors.primary }]}>JSON</Text></Pressable><Pressable onPress={() => runSafely(() => exportAuditFormat("csv"), "Audit export failed")} style={[styles.formatButton, { borderColor: colors.border }]}><Text style={[styles.formatText, { color: colors.primary }]}>CSV</Text></Pressable></View>{selectedAudit.retryEvents.some((event) => event.outcome === "failed") && selectedAudit.status === "found" && <Pressable onPress={() => setRetryConfirmOpen(true)} disabled={!isOnline || syncState === "syncing"} style={[styles.detailButton, { backgroundColor: isOnline ? colors.primary : colors.surface }]}><Text style={[styles.exportText, { color: isOnline ? colors.background : colors.muted }]}>{isOnline ? "Retry failed events" : "Retry when online"}</Text></Pressable>}<Pressable onPress={() => { setSelectedAudit(null); if (selectedAudit.status === "found") onSelect(selectedAudit.label); }} disabled={selectedAudit.status !== "found"} style={[styles.detailButton, { backgroundColor: selectedAudit.status === "found" ? colors.primary : colors.surface }]}><Text style={[styles.exportText, { color: selectedAudit.status === "found" ? colors.background : colors.muted }]}>Open verification handoff</Text></Pressable></>}</View></View></Modal><Modal visible={retryConfirmOpen && selectedAudit !== null} animationType="fade" transparent onRequestClose={() => setRetryConfirmOpen(false)}><View style={styles.modalBackdrop}><View style={[styles.confirmSheet, { backgroundColor: colors.background }]}><Text style={[styles.confirmTitle, { color: colors.foreground }]}>Retry failed events?</Text><Text style={[styles.confirmCopy, { color: colors.muted }]}>{failedEvents.length} failed events will be retried for {selectedAudit?.label}. Affected acknowledgement IDs: {failedEventLabels || "none"}. The attempt will be recorded in the audit timeline.</Text><Pressable onPress={() => { if (selectedAudit) onRetryRecord(selectedAudit.label, true); setRetryConfirmOpen(false); }} style={[styles.detailButton, { backgroundColor: colors.primary }]}><Text style={[styles.exportText, { color: colors.background }]}>Confirm retry</Text></Pressable><Pressable onPress={() => setRetryConfirmOpen(false)} style={[styles.detailButton, { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }]}><Text style={[styles.exportText, { color: colors.foreground }]}>Cancel</Text></Pressable></View></View></Modal></ScreenContainer>;
}

const styles = StyleSheet.create({ container: { flex: 1 }, camera: { flex: 1 }, overlay: { flex: 1, justifyContent: "space-between", padding: 20 },   cameraActions: { alignSelf: "stretch", flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 8 }, close: { flexDirection: "row", alignItems: "center", gap: 3 }, torchButton: { borderWidth: 1, borderColor: "rgba(255,255,255,0.4)", borderRadius: 10, paddingVertical: 7, paddingHorizontal: 10 }, controlGroup: { flexDirection: "row", alignItems: "center", gap: 6 }, zoomText: { color: "#FFFFFF", fontSize: 12, fontWeight: "800", minWidth: 34, textAlign: "center" }, disabledControl: { opacity: 0.4 }, torchText: { color: "#FFFFFF", fontSize: 12, fontWeight: "800" }, closeIcon: { transform: [{ rotate: "180deg" }] }, closeText: { color: "#FFFFFF", fontSize: 14, fontWeight: "800" }, scanArea: { width: 248, height: 248, alignSelf: "center", position: "relative", borderWidth: 1, borderRadius: 18 }, framingBadge: { position: "absolute", bottom: -28, alignSelf: "center", fontSize: 12, fontWeight: "800" }, cameraError: { color: "#FCA5A5", fontSize: 12, lineHeight: 17, marginBottom: 8 }, corner: { position: "absolute", width: 30, height: 30, borderWidth: 3 }, topLeft: { top: 0, left: 0, borderRightWidth: 0, borderBottomWidth: 0 }, topRight: { top: 0, right: 0, borderLeftWidth: 0, borderBottomWidth: 0 }, bottomLeft: { bottom: 0, left: 0, borderRightWidth: 0, borderTopWidth: 0 }, bottomRight: { bottom: 0, right: 0, borderLeftWidth: 0, borderTopWidth: 0 }, bottomPanel: { backgroundColor: "rgba(7,10,18,0.86)", borderRadius: 20, padding: 17, marginBottom: 8 }, scanTitle: { color: "#FFFFFF", fontSize: 18, fontWeight: "800", marginBottom: 5 }, scanMessage: { color: "#CBD5E1", fontSize: 13, lineHeight: 19 }, scanGuidance: { color: "#F8FAFC", fontSize: 12, lineHeight: 17, marginTop: 7 }, syncMessage: { color: "#94A3B8", fontSize: 11, marginTop: 8 }, syncCard: { width: "100%", maxWidth: 320, borderWidth: 1, borderRadius: 16, padding: 13, flexDirection: "row", alignItems: "center", marginBottom: 14 }, syncCopy: { flex: 1 }, syncTitle: { fontSize: 12, fontWeight: "800", marginBottom: 4 }, syncDetail: { fontSize: 11, lineHeight: 16 }, syncAction: { minWidth: 55, minHeight: 34, borderWidth: 1, borderRadius: 10, alignItems: "center", justifyContent: "center", marginLeft: 10 }, syncActionText: { fontSize: 11, fontWeight: "800" }, retry: { minHeight: 42, marginTop: 14, borderRadius: 12, alignItems: "center", justifyContent: "center" }, retryText: { fontSize: 13, fontWeight: "800" }, fallback: { flex: 1, alignItems: "center", justifyContent: "center" }, fallbackIcon: { width: 68, height: 68, borderRadius: 22, alignItems: "center", justifyContent: "center", marginBottom: 18 }, fallbackTitle: { fontSize: 25, fontWeight: "800", marginBottom: 8 },   warningBanner: { borderWidth: 1, borderRadius: 10, padding: 10, marginBottom: 12 },
  warningBannerText: { fontSize: 12, lineHeight: 17 },
  recoveryRetry: { alignSelf: "flex-start", borderWidth: 1, borderRadius: 8, paddingVertical: 6, paddingHorizontal: 10, marginTop: 6 },
  recoveryRetryText: { fontSize: 12, fontWeight: "700" },
  fallbackMessage: { fontSize: 14, lineHeight: 21, textAlign: "center", maxWidth: 300, marginBottom: 20 }, fallbackButton: { minHeight: 47, minWidth: 220, borderRadius: 14, alignItems: "center", justifyContent: "center", marginBottom: 10 }, historyCard: { width: "100%", maxWidth: 320, borderWidth: 1, borderRadius: 20, padding: 16, marginBottom: 14, shadowColor: "#101828", shadowOpacity: 0.04, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 1 }, historyHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }, historyActions: { flexDirection: "row", gap: 12 }, modalBackdrop: { flex: 1, backgroundColor: "rgba(7,10,18,0.42)", justifyContent: "flex-end" }, auditSheet: { maxHeight: "78%", borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20 }, auditHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }, auditTitle: { fontSize: 20, fontWeight: "800" }, auditSubtitle: { fontSize: 12, marginTop: 3 },   activityCard: { borderWidth: 1, borderRadius: 12, padding: 10, gap: 4, marginBottom: 10 },
  auditList: { paddingBottom: 12 }, auditRow: { paddingVertical: 12, borderBottomWidth: 1 }, auditLabel: { fontSize: 13, fontWeight: "800" }, auditMeta: { fontSize: 11, marginTop: 4 }, auditError: { fontSize: 11, marginTop: 4 }, exportButton: { minHeight: 46, borderRadius: 13, alignItems: "center", justifyContent: "center" }, exportText: { fontSize: 13, fontWeight: "800" }, detailSheet: { width: "100%", borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20 }, detailStatus: { fontSize: 15, fontWeight: "800", marginBottom: 10 }, detailButton: { minHeight: 46, borderRadius: 13, alignItems: "center", justifyContent: "center", marginTop: 20 }, formatRow: { flexDirection: "row", gap: 8, marginTop: 10 }, formatButton: { flex: 1, minHeight: 38, borderWidth: 1, borderRadius: 10, alignItems: "center", justifyContent: "center" }, formatText: { fontSize: 11, fontWeight: "800" }, confirmSheet: { width: "100%", borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20 }, confirmTitle: { fontSize: 20, fontWeight: "800", marginBottom: 8 }, confirmCopy: { fontSize: 13, lineHeight: 20 }, eventFilterRow: { flexDirection: "row", gap: 6, marginTop: 12, marginBottom: 6 }, eventList: { maxHeight: 220, marginTop: 8 }, eventListContent: { paddingBottom: 4 }, eventRow: { flexDirection: "row", alignItems: "flex-start", paddingVertical: 10, borderBottomWidth: 1, gap: 9 }, eventDot: { width: 8, height: 8, borderRadius: 4, marginTop: 4 }, eventCopy: { flex: 1 }, historyTitle: { fontSize: 13, fontWeight: "800" }, clearText: { fontSize: 11, fontWeight: "800" }, historyRow: { flexDirection: "row", alignItems: "center", minHeight: 42, paddingVertical: 7, gap: 8 }, historyDot: { width: 7, height: 7, borderRadius: 4 }, historyLabel: { flex: 1, fontSize: 12, fontWeight: "700" }, historyTime: { fontSize: 11 }, historyAttempt: { fontSize: 9 }, historyError: { fontSize: 9, flexBasis: "100%" }, historyStatus: { fontSize: 10, fontWeight: "800" }, filterRow: { flexDirection: "row", gap: 6, marginBottom: 10 }, filterChip: { borderWidth: 1, borderRadius: 10, minHeight: 36, paddingHorizontal: 10, paddingVertical: 8, justifyContent: "center" }, filterText: { fontSize: 10, fontWeight: "800" }, emptyHistory: { fontSize: 11, paddingVertical: 8 }, rowRetry: { borderWidth: 1, borderRadius: 8, paddingHorizontal: 7, paddingVertical: 4 }, rowRetryText: { fontSize: 10, fontWeight: "800" }, secondaryButton: { minHeight: 47, minWidth: 220, borderRadius: 14, borderWidth: 1, alignItems: "center", justifyContent: "center" }, secondaryText: { fontSize: 13, fontWeight: "800" } });
