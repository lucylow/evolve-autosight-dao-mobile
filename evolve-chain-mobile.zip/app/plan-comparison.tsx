import { useEffect, useMemo, useState } from "react";
import { Linking, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { getFeatureLabel, getUpgradeMessage, isFeatureEntitled, PLAN_DEFINITIONS, type MonetizationFeature, type MonetizationPlan } from "@/lib/monetization";
import { loadUpgradeRequests, loadWorkspacePlan, recordUpgradeRequest, type UpgradeRequest } from "@/lib/workspace-plan";

const FEATURES: MonetizationFeature[] = ["inspectionCapture", "auditExports", "teamCalibration", "advancedTriage"];

export default function PlanComparisonScreen() {
  const colors = useColors();
  const router = useRouter();
  const [currentPlan, setCurrentPlan] = useState<MonetizationPlan>("community");
  const [organization, setOrganization] = useState("");
  const [requestSent, setRequestSent] = useState(false);
  const [requestHistory, setRequestHistory] = useState<UpgradeRequest[]>([]);
  const [storageNotice, setStorageNotice] = useState<string | null>(null);
  const recommendedPlan = useMemo(() => PLAN_DEFINITIONS.find((plan) => plan.id === "operations"), []);

  useEffect(() => {
    let active = true;
    void Promise.all([loadWorkspacePlan(), loadUpgradeRequests()]).then(([workspace, history]) => {
      if (!active) return;
      setCurrentPlan(workspace.plan);
      setRequestHistory(history.requests);
      if (workspace.recovered || history.recovered) setStorageNotice("Some workspace monetization history was unavailable and was safely ignored.");
    });
    return () => { active = false; };
  }, []);

  const prepareRequest = async () => {
    const subject = encodeURIComponent(`Evolve Insight ${recommendedPlan?.label ?? "Operations"} plan request`);
    const body = encodeURIComponent(
      `I would like to discuss an Evolve Insight organization plan.${organization.trim() ? ` Organization: ${organization.trim()}.` : ""}\n\nPlease share availability and next steps. No inspection images or private evidence are included in this request.`,
    );
    const saved = await recordUpgradeRequest({ requestedPlan: recommendedPlan?.id === "network" ? "network" : "operations", organizationLabel: organization });
    setRequestSent(true);
    if (saved.ok) setRequestHistory((previous) => [saved.request, ...previous].slice(0, 10));
    else setStorageNotice("The request is ready, but its local history could not be saved.");
    try {
      await Linking.openURL(`mailto:sales@evolveinsight.example?subject=${subject}&body=${body}`);
    } catch {
      // The confirmation remains useful when an email client is unavailable.
    }
  };

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]}>
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <Pressable onPress={() => router.back()} style={({ pressed }) => [styles.back, pressed && { opacity: 0.65 }]}>
          <IconSymbol name="chevron.right" size={18} color={colors.primary} style={styles.backIcon} />
          <Text style={[styles.backText, { color: colors.primary }]}>Profile</Text>
        </Pressable>
        <Text style={[styles.eyebrow, { color: colors.primary }]}>WORKSPACE PLANS</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>Choose the right level of audit confidence.</Text>
        <Text style={[styles.subtitle, { color: colors.muted }]}>Start with local inspection capture, then add the operational controls your organization needs. Plan requests never include raw images or private evidence.</Text>

        <View style={styles.planList}>
          {PLAN_DEFINITIONS.map((plan) => (
            <View key={plan.id} style={[styles.planCard, { backgroundColor: colors.surface, borderColor: plan.id === currentPlan ? colors.primary : colors.border }]}>
              <View style={styles.planHeader}>
                <View style={styles.planTitleWrap}>
                  <Text style={[styles.planName, { color: colors.foreground }]}>{plan.label}</Text>
                  {plan.id === currentPlan && <View style={[styles.currentBadge, { backgroundColor: `${colors.primary}16` }]}><Text style={[styles.currentBadgeText, { color: colors.primary }]}>Current</Text></View>}
                </View>
                <IconSymbol name={plan.id === "network" ? "sparkles" : "shield.fill"} size={20} color={plan.id === currentPlan ? colors.primary : colors.muted} />
              </View>
              <Text style={[styles.positioning, { color: colors.muted }]}>{plan.positioning}</Text>
              <View style={styles.featureList}>
                {FEATURES.map((feature) => {
                  const entitled = isFeatureEntitled(plan.id, feature);
                  return <View key={feature} style={styles.featureRow}><IconSymbol name={entitled ? "checkmark.seal.fill" : "lock.fill"} size={16} color={entitled ? colors.success : colors.muted} /><Text style={[styles.featureText, { color: entitled ? colors.foreground : colors.muted }]}>{getFeatureLabel(feature)}</Text></View>;
                })}
              </View>
              {plan.id !== currentPlan && <Text style={[styles.valueNote, { color: colors.primary }]}>{getUpgradeMessage(plan.id === "network" ? "advancedTriage" : "auditExports")}</Text>}
            </View>
          ))}
        </View>

        <View style={[styles.requestCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.requestEyebrow, { color: colors.primary }]}>ORGANIZATION ACCESS</Text>
          <Text style={[styles.requestTitle, { color: colors.foreground }]}>Discuss Operations or Network</Text>
          <Text style={[styles.requestBody, { color: colors.muted }]}>Prepare a sales request for workspace-level exports, shared calibration, advanced triage, and partner-scale governance. You remain in control of sending it.</Text>
          <TextInput value={organization} onChangeText={setOrganization} placeholder="Organization name (optional)" placeholderTextColor={colors.muted} style={[styles.input, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.background }]} returnKeyType="done" />
          <Pressable onPress={prepareRequest} style={({ pressed }) => [styles.requestButton, { backgroundColor: colors.primary }, pressed && { opacity: 0.78 }]}><Text style={[styles.requestButtonText, { color: colors.background }]}>{requestSent ? "Request prepared" : "Prepare request"}</Text><IconSymbol name="arrow.up.right" size={16} color={colors.background} /></Pressable>
          {requestSent && <Text style={[styles.confirmation, { color: colors.success }]}>A privacy-safe request is ready. If no mail client opened, contact your organization administrator or Evolve directly.</Text>}
          {storageNotice && <Text style={[styles.confirmation, { color: colors.warning }]}>{storageNotice}</Text>}
          {requestHistory.length > 0 && <View style={[styles.history, { borderTopColor: colors.border }]}><Text style={[styles.historyTitle, { color: colors.foreground }]}>Request history</Text>{requestHistory.slice(0, 3).map((request) => <Text key={request.id} style={[styles.historyItem, { color: colors.muted }]}>{request.requestedPlan === "network" ? "Network" : "Operations"} · {request.status} · {new Date(request.createdAt).toLocaleDateString()}</Text>)}</View>}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { padding: 20, paddingBottom: 34 },
  back: { flexDirection: "row", alignItems: "center", minHeight: 34, marginBottom: 18 },
  backIcon: { transform: [{ rotate: "180deg" }], marginRight: 2 },
  backText: { fontSize: 13, fontWeight: "800" },
  eyebrow: { fontSize: 11, letterSpacing: 1.5, fontWeight: "800", marginBottom: 8 },
  title: { fontSize: 28, lineHeight: 34, fontWeight: "800", letterSpacing: -0.6, marginBottom: 9 },
  subtitle: { fontSize: 14, lineHeight: 21, marginBottom: 20 },
  planList: { gap: 12, marginBottom: 18 },
  planCard: { borderWidth: 1, borderRadius: 18, padding: 15 },
  planHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  planTitleWrap: { flexDirection: "row", alignItems: "center", gap: 8 },
  planName: { fontSize: 18, fontWeight: "800" },
  currentBadge: { borderRadius: 999, paddingHorizontal: 8, paddingVertical: 4 },
  currentBadgeText: { fontSize: 10, fontWeight: "800" },
  positioning: { fontSize: 12, lineHeight: 18, marginTop: 8, marginBottom: 12 },
  featureList: { gap: 8 },
  featureRow: { flexDirection: "row", alignItems: "center", gap: 7 },
  featureText: { fontSize: 12, fontWeight: "700" },
  valueNote: { fontSize: 11, lineHeight: 16, marginTop: 13 },
  requestCard: { borderWidth: 1, borderRadius: 18, padding: 16 },
  requestEyebrow: { fontSize: 10, letterSpacing: 1.3, fontWeight: "800", marginBottom: 6 },
  requestTitle: { fontSize: 18, fontWeight: "800", marginBottom: 7 },
  requestBody: { fontSize: 12, lineHeight: 18, marginBottom: 13 },
  input: { borderWidth: 1, borderRadius: 11, minHeight: 44, paddingHorizontal: 12, fontSize: 13, marginBottom: 10 },
  requestButton: { minHeight: 44, borderRadius: 12, paddingHorizontal: 13, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  requestButtonText: { fontSize: 13, fontWeight: "800" },
  confirmation: { fontSize: 11, lineHeight: 16, marginTop: 10 },
  history: { borderTopWidth: 1, marginTop: 14, paddingTop: 12 },
  historyTitle: { fontSize: 12, fontWeight: "800", marginBottom: 6 },
  historyItem: { fontSize: 11, lineHeight: 17 },
});
