import { describe, expect, it } from "vitest";

import { getFailureCategory, validateOperatorActivityText } from "../lib/operator-activity";

describe("operator activity validation", () => {
  it("accepts a valid JSON activity envelope", () => {
    const result = validateOperatorActivityText(JSON.stringify({ schemaVersion: 1, records: [{ id: "a1", time: "2026-08-18T10:00:00.000Z", kind: "batch-retry", summary: "Retried 2 due records", detail: "2 succeeded" }] }), "json");
    expect(result.valid).toBe(true);
    expect(result.recordCount).toBe(1);
  });

  it("rejects malformed activity metadata and unknown event kinds", () => {
    expect(validateOperatorActivityText(JSON.stringify({ records: [] }), "json").valid).toBe(false);
    expect(validateOperatorActivityText(JSON.stringify({ schemaVersion: 1, records: [{ id: "a1", time: "now", kind: "unknown", summary: "x", detail: "y" }] }), "json").valid).toBe(false);
  });

  it("categorizes recoverable acknowledgement failures", () => {
    expect(getFailureCategory("Backend acknowledgement unavailable · retry when online")).toBe("Backend acknowledgement");
    expect(getFailureCategory("No connection · retry when online")).toBe("Offline connectivity");
    expect(getFailureCategory("Unexpected failure")).toBe("Other");
  });
});
