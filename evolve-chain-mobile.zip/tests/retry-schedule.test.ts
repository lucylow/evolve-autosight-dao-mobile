import { describe, expect, it } from "vitest";

import { formatNextAttempt, formatRetryCountdown, getNextAttemptAt, isRetryDue } from "../lib/retry-schedule";

describe("retry scheduling", () => {
  it("uses bounded exponential delays", () => {
    const now = new Date("2026-08-18T16:00:00.000Z");
    expect(getNextAttemptAt(now, 1)).toBe("2026-08-18T16:00:30.000Z");
    expect(getNextAttemptAt(now, 2)).toBe("2026-08-18T16:01:00.000Z");
    expect(getNextAttemptAt(now, 8)).toBe("2026-08-18T16:15:00.000Z");
  });

  it("formats a next-attempt timestamp for the operator", () => {
    expect(formatNextAttempt("2026-08-18T16:05:00.000Z")).toMatch(/:05/);
    expect(formatNextAttempt()).toBe("");
  });

  it("blocks scheduled retries until their window is due", () => {
    const now = new Date("2026-08-18T16:00:00.000Z").getTime();
    expect(isRetryDue("2026-08-18T16:00:30.000Z", now)).toBe(false);
    expect(isRetryDue("2026-08-18T15:59:59.000Z", now)).toBe(true);
    expect(isRetryDue(undefined, now)).toBe(true);
  });

  it("renders live retry countdown states", () => {
    const now = new Date("2026-08-18T16:00:00.000Z").getTime();
    expect(formatRetryCountdown("2026-08-18T16:01:05.000Z", now)).toBe("Retry in 1m 5s");
    expect(formatRetryCountdown("2026-08-18T16:00:00.000Z", now)).toBe("Retry due now");
  });
});
