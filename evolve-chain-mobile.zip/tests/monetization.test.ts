import { describe, expect, it } from "vitest";

import { getFeatureLabel, getUpgradeMessage, isFeatureEntitled } from "../lib/monetization";
import { formatPlanChangeHistory, recordPlanChange } from "../lib/workspace-plan";

describe("monetization entitlements", () => {
  it("keeps local inspection capture available on the community plan", () => {
    expect(isFeatureEntitled("community", "inspectionCapture")).toBe(true);
    expect(isFeatureEntitled("community", "auditExports")).toBe(false);
  });

  it("describes team value without exposing private evidence", () => {
    expect(getFeatureLabel("teamCalibration")).toBe("Team calibration");
    expect(getUpgradeMessage("auditExports")).toContain("privacy-safe quality summaries");
    expect(getUpgradeMessage("auditExports")).not.toContain("image");
  });

  it("keeps organization capabilities grouped above the community tier", () => {
    expect(isFeatureEntitled("operations", "auditExports")).toBe(true);
    expect(isFeatureEntitled("operations", "advancedTriage")).toBe(true);
    expect(isFeatureEntitled("network", "teamCalibration")).toBe(true);
    expect(isFeatureEntitled("community", "advancedTriage")).toBe(false);
  });

  it("exports only privacy-safe plan history metadata", () => {
    const csv = formatPlanChangeHistory([{ id: "1", from: "community", to: "operations", actor: "workspace-admin", reason: "Pilot, export workflow", createdAt: "2026-08-18T00:00:00.000Z", authorizationSource: "local-preview-only" }]);
    expect(csv).toContain("authorizationSource");
    expect(csv).toContain("local-preview-only");
    expect(csv).toContain("Pilot  export workflow");
    expect(csv).not.toContain("imageUri");
  });

  it("records plan changes as local preview events without private evidence", async () => {
    const result = await recordPlanChange({ from: "community", to: "operations", reason: "Pilot export workflow" });
    expect(result.event.actor).toBe("workspace-admin");
    expect(result.event.authorizationSource).toBe("local-preview-only");
    expect(result.event.reason).toBe("Pilot export workflow");
    expect("includesPrivateEvidence" in result.event).toBe(false);
  });
});
