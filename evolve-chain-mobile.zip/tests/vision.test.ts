import { describe, expect, it } from "vitest";

import { clampCameraZoom, classifyScanPayload, formatInspectionPhotoDiagnostics, formatScanSessionSummary, getCaptureReadiness, getFramingState, getCalibrationBreakdown, getComponentAlignment, getConfidenceTrend, getEvidenceConfidence, getInspectionCaptureReadiness, getInspectionFrameTemplateGuidance, getInspectionFramingGuidance, getInspectionPhotoQuality, getInspectionPhotoReadiness, getScanConfidenceLabel, MAX_CAMERA_ZOOM, MIN_CAMERA_ZOOM, scanGuidance } from "../lib/vision";
import { estimatePixelQuality, PIXEL_REGIONS } from "../lib/pixel-metrics";

describe("computer-vision scan guidance", () => {
  it("classifies valid verification payloads", () => {
    const result = classifyScanPayload("https://evolve.local/verify/EV-39281");
    expect(result.quality).toBe("verification");
    expect(result.normalizedValue).toContain("EV-39281");
  });

  it("distinguishes unreadable and unrelated codes", () => {
    expect(classifyScanPayload("   ").quality).toBe("empty");
    expect(classifyScanPayload("https://example.com/item/123").quality).toBe("malformed");
  });

  it("clamps zoom to the supported camera range", () => {
    expect(clampCameraZoom(-1)).toBe(MIN_CAMERA_ZOOM);
    expect(clampCameraZoom(9)).toBe(MAX_CAMERA_ZOOM);
    expect(clampCameraZoom(Number.NaN)).toBe(MIN_CAMERA_ZOOM);
  });

  it("reports capture readiness for lighting and framing", () => {
    expect(getCaptureReadiness(false, "empty", 0).state).toBe("needs-light");
    expect(getCaptureReadiness(false, "malformed", 0.7).message).toContain("Zoom is high");
    expect(getCaptureReadiness(true, "verification", 0).state).toBe("ready");
  });

  it("reports framing and confidence states", () => {
    expect(getFramingState("verification", 0).state).toBe("clear");
    expect(getFramingState("verification", 0.7).label).toContain("Zoom out");
    expect(getScanConfidenceLabel("verification")).toContain("High confidence");
    expect(getScanConfidenceLabel("empty")).toContain("Waiting");
  });

  it("formats scan-session quality context", () => {
    expect(formatScanSessionSummary({ readable: 1, verified: 1, adjustments: 2 })).toBe("1 readable attempt · 1 verified · 2 framing adjustments");
    expect(formatScanSessionSummary({ readable: 0, verified: 0, adjustments: 0 })).toBe("0 readable attempts · 0 verified");
  });

  it("evaluates inspection photo readiness from safe metadata", () => {
    expect(getInspectionPhotoReadiness({}).label).toBe("Capture unavailable");
    expect(getInspectionPhotoReadiness({ uri: "file://small", width: 320, height: 240 }).ready).toBe(false);
    expect(getInspectionPhotoReadiness({ uri: "file://review", width: 1280, height: 960 }).label).toBe("Image ready for review");
  });

  it("scores inspection photo quality without pretending missing metadata is certainty", () => {
    expect(getInspectionPhotoQuality({}).state).toBe("improve");
    expect(getInspectionPhotoQuality({ uri: "file://small", width: 320, height: 240 }).guidance).toContain("Move closer");
    expect(getInspectionPhotoQuality({ uri: "file://review", width: 960, height: 720 }).state).toBe("review");
    expect(getInspectionPhotoQuality({ uri: "file://ready", width: 1280, height: 960, exif: { PixelXDimension: 1280 }, fileSize: 80_000 }).state).toBe("ready");
  });

  it("estimates pixel blur and exposure from bounded luminance samples", () => {
    const flat = Array.from({ length: 64 }, () => ({ luminance: 128 }));
    const textured = Array.from({ length: 64 }, (_, index) => ({ luminance: index % 2 ? 30 : 220 }));
    expect(estimatePixelQuality(flat).state).toBe("poor");
    expect(estimatePixelQuality(textured).exposureScore).toBeGreaterThan(60);
    expect(estimatePixelQuality(textured).blurScore).toBeGreaterThan(80);
    expect(estimatePixelQuality(textured).confidenceBand).toBe("medium");
    expect(estimatePixelQuality(textured).edgeScore).toBeGreaterThan(40);
    expect(estimatePixelQuality(textured).geometryState).toBe("strong");
    expect(estimatePixelQuality(textured).geometryExplanation).toContain("edge transitions");
    expect(estimatePixelQuality(textured).explanation).toContain("visible texture");
    expect(estimatePixelQuality([]).state).toBe("unavailable");
    expect(estimatePixelQuality([]).explanation).toContain("incomplete");
    expect(estimatePixelQuality([]).geometryState).toBe("unavailable");
    expect(estimatePixelQuality([]).geometryExplanation).toContain("unavailable");
  });

  it("focuses pixel scoring on the selected component region", () => {
    const samples = [
      ...Array.from({ length: 64 }, () => ({ luminance: 128, x: 0.02, y: 0.02 })),
      ...Array.from({ length: 64 }, (_, index) => ({ luminance: index % 2 ? 30 : 220, x: 0.5, y: 0.5 })),
    ];
    expect(estimatePixelQuality(samples).blurScore).toBeGreaterThan(40);
    expect(estimatePixelQuality(samples, PIXEL_REGIONS.label).blurScore).toBeGreaterThan(40);
  });

  it("exposes component calibration weights and contributions", () => {
    const label = getCalibrationBreakdown("label", { metadataScore: 80, pixelScore: 70, alignmentScore: 90, edgeScore: 60 });
    expect(label.find((signal) => signal.key === "alignment")?.weight).toBe(0.3);
    expect(label.find((signal) => signal.key === "pixel")?.contribution).toBe(21);
    expect(getCalibrationBreakdown("housing", { metadataScore: null, pixelScore: null, alignmentScore: null, edgeScore: null }).every((signal) => signal.contribution === null)).toBe(true);
  });

  it("tracks repeated-capture confidence trends", () => {
    expect(getConfidenceTrend(88, 70).label).toBe("Confidence improving");
    expect(getConfidenceTrend(52, 70).label).toBe("Confidence declining");
    expect(getConfidenceTrend(74, 70).label).toBe("Confidence stable");
    expect(getConfidenceTrend(80, null).label).toBe("Single capture");
  });

  it("aggregates evidence confidence and explains disagreement", () => {
    expect(getEvidenceConfidence({ metadataScore: 92, pixelScore: 90, alignmentScore: 88, edgeScore: 84 }).state).toBe("high");
    expect(getEvidenceConfidence({ metadataScore: 95, pixelScore: 30, alignmentScore: 90, edgeScore: 20 }).guidance).toContain("Signals disagree");
    expect(getEvidenceConfidence({ metadataScore: null, pixelScore: null, alignmentScore: null, edgeScore: null }).state).toBe("unavailable");
  });

  it("evaluates component perspective and edge alignment", () => {
    expect(getComponentAlignment("housing").state).toBe("unavailable");
    expect(getComponentAlignment("label", { width: 1750, height: 1000 }).state).toBe("aligned");
    expect(getComponentAlignment("label", { width: 3000, height: 700 }).state).toBe("adjust");
    expect(getComponentAlignment("label", { width: 1750, height: 1000, exif: { Orientation: 6 } }).score).toBeLessThan(90);
  });

  it("provides component-specific framing templates", () => {
    expect(getInspectionFrameTemplateGuidance("label").message).toContain("printed characters");
    expect(getInspectionFrameTemplateGuidance("flat-surface").message).toContain("even lighting");
    expect(getInspectionFrameTemplateGuidance("housing", { width: 2400, height: 800 }).label).toContain("Adjust housing");
  });

  it("formats capture diagnostics without inventing unavailable evidence", () => {
    expect(formatInspectionPhotoDiagnostics({})).toEqual(["Resolution unavailable", "Aspect ratio unavailable", "EXIF metadata unavailable", "File size unavailable"]);
    expect(formatInspectionPhotoDiagnostics({ width: 1280, height: 960, fileSize: 81_920, exif: {}, capturedAt: "2026-08-18T12:00:00.000Z", frameTemplate: "label", pixelBlurScore: 72, pixelExposureScore: 88, pixelConfidenceBand: "high", pixelExplanation: "visible texture; balanced exposure", alignmentScore: 88, alignmentState: "aligned" })).toEqual(expect.arrayContaining(["Resolution 1280 × 960", "Aspect ratio 1.33:1", "EXIF metadata available", "File size 80 KB", "Frame template Label", "Pixel confidence high", "Pixel rationale: visible texture; balanced exposure", "Alignment score 88", "Alignment state aligned"]));
  });

  it("provides framing guidance for unknown and extreme aspect ratios", () => {
    expect(getInspectionFramingGuidance().label).toBe("Frame the component");
    expect(getInspectionFramingGuidance({ width: 2400, height: 800 }).label).toBe("Adjust orientation");
    expect(getInspectionFramingGuidance({ width: 1280, height: 960 }).message).toContain("small margin");
  });

  it("evaluates inspection capture readiness from confidence and evidence", () => {
    expect(getInspectionCaptureReadiness(94, ["Component centered", "Image quality passed"]).ready).toBe(true);
    expect(getInspectionCaptureReadiness(88, ["Image quality passed"]).label).toBe("Review capture");
    expect(getInspectionCaptureReadiness(98, ["Label matched"]).message).toContain("Center the component");
  });

  it("changes guidance when the torch is enabled", () => {
    expect(scanGuidance(false, "malformed")).toContain("lighting");
    expect(scanGuidance(true, "malformed")).toContain("flat and centered");
    expect(scanGuidance(false, "verification")).toContain("Hold steady");
  });
});
