import { describe, expect, it } from "vitest";
import { validateAuditFileText } from "../lib/audit-file";

const json = JSON.stringify({
  schemaVersion: 1,
  exportedAt: "2026-08-18T00:00:00.000Z",
  exportFileName: "evolve-part-audit-all.json",
  dateRange: "all",
  eventFilter: "all",
  records: [{ record: "EV-001", state: "synced", time: "10:00", outcome: "synced", network: "wifi", acknowledgementId: "ack-1", detail: "Acknowledged" }],
});

const csv = [
  "# Evolve Insight Audit Export",
  "# schemaVersion=1",
  "# exportedAt=2026-08-18T00:00:00.000Z",
  "# exportFileName=evolve-part-audit-all.csv",
  "# dateRange=all",
  "# eventFilter=all",
  "record,state,time,outcome,network,acknowledgementId,detail",
  'EV-001,synced,10:00,synced,wifi,ack-1,"Acknowledged"',
].join("\n");

describe("audit file validation", () => {
  it("accepts a complete JSON envelope", () => {
    expect(validateAuditFileText(json, "json")).toMatchObject({ valid: true, recordCount: 1, format: "json" });
  });

  it("rejects JSON with a missing acknowledgement ID", () => {
    expect(validateAuditFileText(json.replace('"ack-1"', '""'), "json").valid).toBe(false);
  });

  it("accepts a complete CSV envelope", () => {
    expect(validateAuditFileText(csv, "csv")).toMatchObject({ valid: true, recordCount: 1, format: "csv" });
  });

  it("accepts CSV retry scheduling metadata", () => {
    const extended = csv.replace("record,state,time,outcome,network,acknowledgementId,detail", "record,state,time,outcome,network,acknowledgementId,detail,nextAttemptAt,retryCountdown").replace('"Acknowledged"', '"Acknowledged",2026-08-18T16:05:00.000Z,"Retry in 30s"');
    expect(validateAuditFileText(extended, "csv")).toMatchObject({ valid: true, recordCount: 1, format: "csv" });
  });

  it("rejects CSV with a tampered header", () => {
    expect(validateAuditFileText(csv.replace("acknowledgementId", "ackId"), "csv").valid).toBe(false);
  });

  it("preserves preview metadata for a validated export", () => {
    const result = validateAuditFileText(json, "json");
    expect(result.envelope).toMatchObject({ exportFileName: "evolve-part-audit-all.json", dateRange: "all", eventFilter: "all" });
  });

  it("rejects a validated-looking file with incomplete metadata", () => {
    const incompleteValue = JSON.parse(json) as { eventFilter: string };
    incompleteValue.eventFilter = "";
    expect(validateAuditFileText(JSON.stringify(incompleteValue), "json").valid).toBe(false);
  });
});
